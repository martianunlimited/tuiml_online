"""NumPy-based prediction engine for flattened and recursive tree structures."""

from __future__ import annotations

import numpy as np

from .nodes import TreeNode, FlattenedTree


def build_jit_functions():
    """Backward-compatible no-op retained for older imports."""
    return None


def _predict_single_flat(flat_tree: FlattenedTree, x: np.ndarray) -> np.ndarray:
    """Traverse a flattened tree for one sample."""
    node_idx = 0
    while flat_tree.children_left[node_idx] != -1:
        feat = flat_tree.feature[node_idx]
        if x[feat] <= flat_tree.threshold[node_idx]:
            node_idx = flat_tree.children_left[node_idx]
        else:
            node_idx = flat_tree.children_right[node_idx]
    return flat_tree.value[node_idx]


def predict_batch(flat_tree: FlattenedTree, X: np.ndarray) -> np.ndarray:
    """Predict over a batch of samples using flattened NumPy tree arrays."""
    # float64 (not float32): the split thresholds are float64, so downcasting
    # the input rounds feature values across split boundaries and misroutes
    # samples, which silently corrupted predictions (catastrophically on
    # data with high-precision features).
    X = np.asarray(X, dtype=np.float64)
    if X.ndim == 1:
        X = X.reshape(1, -1)
    return np.array([_predict_single_flat(flat_tree, x) for x in X], dtype=np.float64)


def predict_proba_batch(flat_tree: FlattenedTree, X: np.ndarray) -> np.ndarray:
    """Predict class probabilities for a batch of samples."""
    return predict_batch(flat_tree, X)


def predict_single_numpy(node: TreeNode, x: np.ndarray) -> np.ndarray:
    """Traverse a recursive tree for one sample (NumPy).

    Missing values follow ``NaN <= threshold`` being False and go right, which
    is how the tree was partitioned during fitting and how the flattened
    batch predictor above routes them. This used to send them to whichever
    child held more training samples, which disagreed with both — so a batch
    call and a single-sample call could return different classes for the same
    row. The three now share one rule.
    """
    while not node.is_leaf:
        if x[node.feature_index] <= node.threshold:
            node = node.left
        else:
            node = node.right
    return node.value


