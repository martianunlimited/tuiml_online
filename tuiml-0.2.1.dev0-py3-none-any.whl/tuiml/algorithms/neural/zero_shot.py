"""Hugging Face Zero-Shot Text Classifier for TuiML."""

from typing import Any, Dict, List, Optional, Union
import numpy as np

from tuiml.base.algorithms import Classifier, classifier

_EXTRA = "huggingface"


def _ensure_transformers():
    """Ensure transformers and torch are installed."""
    try:
        import torch  # noqa: F401
        import transformers  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            f"HFZeroShotClassifier requires 'transformers' and 'torch'. "
            f"Install them with: pip install 'tuiml[{_EXTRA}]'"
        ) from exc


@classifier(tags=["huggingface", "nlp", "zero-shot", "neural", "transformers"], version="1.0.0")
class HFZeroShotClassifier(Classifier):
    """Zero-shot text classifier using Hugging Face Natural Language Inference (NLI) models.

    Classifies text sequences into user-specified candidate labels without requiring
    any training data or weight updates. If candidate labels are not passed in the
    constructor, they can optionally be inferred from target labels in ``fit()``.

    Parameters
    ----------
    candidate_labels : list of str, optional
        Target class label names to score against. Can also be inferred from ``y`` during ``fit()``.
    model_name : str, default="typeform/distilbert-base-uncased-mnli"
        NLI model identifier on Hugging Face Hub (e.g. ``"typeform/distilbert-base-uncased-mnli"``
        or ``"facebook/bart-large-mnli"``).
    hypothesis_template : str, default="This text is about {}."
        Template phrasing used by the NLI backbone for label entailment.
    multi_label : bool, default=False
        Whether multiple candidate labels can be independently true.
    batch_size : int, default=16
        Inference batch size.
    device : str, default="auto"
        Compute device: ``"auto"`` (CUDA if available), ``"cuda"``, or ``"cpu"``.

    Attributes
    ----------
    classes_ : np.ndarray
        Array of candidate class labels.
    pipeline_ : Pipeline
        Loaded Hugging Face zero-shot classification pipeline.
    """

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Dict[str, Any]]:
        """Return parameter schema for introspection."""
        return {
            "candidate_labels": {
                "type": "list",
                "default": None,
                "description": "Candidate category labels to classify into.",
            },
            "model_name": {
                "type": "str",
                "default": "typeform/distilbert-base-uncased-mnli",
                "description": "Pretrained NLI model on Hugging Face Hub.",
            },
            "hypothesis_template": {
                "type": "str",
                "default": "This text is about {}.",
                "description": "Template used to pose the classification hypothesis.",
            },
            "multi_label": {
                "type": "bool",
                "default": False,
                "description": "Whether classes are mutually exclusive.",
            },
            "batch_size": {
                "type": "int",
                "default": 16,
                "description": "Inference batch size.",
            },
            "device": {
                "type": "str",
                "default": "auto",
                "options": ["auto", "cuda", "cpu"],
                "description": "Compute device.",
            },
        }

    def __init__(
        self,
        candidate_labels: Optional[List[str]] = None,
        model_name: str = "typeform/distilbert-base-uncased-mnli",
        hypothesis_template: str = "This text is about {}.",
        multi_label: bool = False,
        batch_size: int = 16,
        device: str = "auto",
    ):
        super().__init__()
        self.candidate_labels = list(candidate_labels) if candidate_labels is not None else None
        self.model_name = model_name
        self.hypothesis_template = hypothesis_template
        self.multi_label = multi_label
        self.batch_size = batch_size
        self.device = device

    def _resolve_device(self) -> int:
        """Return device index for Hugging Face pipeline (-1 for CPU, 0 for CUDA)."""
        import torch

        if self.device == "auto":
            return 0 if torch.cuda.is_available() else -1
        if self.device == "cuda":
            return 0
        return -1

    def _load_pipeline(self):
        """Initialize the zero-shot classification pipeline lazily."""
        _ensure_transformers()
        from transformers import pipeline

        device = self._resolve_device()
        self.pipeline_ = pipeline(
            "zero-shot-classification",
            model=self.model_name,
            device=device,
        )

    def fit(self, X: Any = None, y: Optional[Any] = None) -> "HFZeroShotClassifier":
        """Configure candidate labels and prepare classifier.

        Parameters
        ----------
        X : array-like of shape (n_samples,), optional
            Input text samples (unused during zero-shot fitting).
        y : array-like of shape (n_samples,), optional
            Target labels. If ``candidate_labels`` was not specified during
            initialization, candidate labels are inferred from unique values of ``y``.
        """
        if self.candidate_labels is None:
            if y is not None:
                self.candidate_labels = [str(lbl) for lbl in np.unique(y)]
            else:
                raise ValueError(
                    "Either 'candidate_labels' must be provided in __init__, or 'y' must be passed to fit()."
                )

        self.classes_ = np.array(self.candidate_labels)
        self._load_pipeline()
        self._is_fitted = True
        return self

    def _normalize_inputs(self, X: Any) -> List[str]:
        """Convert input X into a list of strings."""
        if isinstance(X, str):
            return [X]
        if isinstance(X, np.ndarray):
            return [str(x) for x in X.flatten()]
        return [str(x) for x in X]

    def predict_proba(self, X: Any) -> np.ndarray:
        """Predict class probabilities for input texts."""
        self._check_is_fitted()
        import torch

        texts = self._normalize_inputs(X)
        if len(texts) == 0:
            return np.empty((0, len(self.classes_)), dtype=np.float32)

        results = self.pipeline_(
            texts,
            candidate_labels=list(self.classes_),
            hypothesis_template=self.hypothesis_template,
            multi_label=self.multi_label,
            batch_size=self.batch_size,
        )

        if isinstance(results, dict):
            results = [results]

        n_samples = len(texts)
        n_classes = len(self.classes_)
        proba_matrix = np.zeros((n_samples, n_classes), dtype=np.float32)

        class_to_idx = {cls_name: idx for idx, cls_name in enumerate(self.classes_)}

        for i, res in enumerate(results):
            for label, score in zip(res["labels"], res["scores"]):
                if label in class_to_idx:
                    proba_matrix[i, class_to_idx[label]] = score

        if self._resolve_device() >= 0:
            torch.cuda.empty_cache()

        return proba_matrix

    def predict(self, X: Any) -> np.ndarray:
        """Predict the most probable class label for each text sample."""
        probas = self.predict_proba(X)
        best_indices = np.argmax(probas, axis=1)
        return self.classes_[best_indices]
