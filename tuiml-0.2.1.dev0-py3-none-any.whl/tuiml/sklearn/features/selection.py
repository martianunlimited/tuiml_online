"""scikit-learn selection wrappers.

Generated from the ``FEATURES_SELECTION`` table in :mod:`tuiml.sklearn.specs`.
Registered under ``sklearn.<ClassName>`` hub keys, mirroring the native
TuiML ``features/selection`` family.
"""


from typing import Any, Dict, List

from tuiml.base.features import FeatureSelector
from tuiml.sklearn._base import (
    _SklearnSelectorMixin,
    sk_feature_selector,
)
from tuiml.sklearn._spec import build_estimator, derive_schema

from tuiml.sklearn.specs import FEATURES_SELECTION as _SPECS

_BY_NAME = {s.name: s for s in _SPECS}


@sk_feature_selector(tags=['selection', 'feature-selection', 'sklearn-extended'])
class GenericUnivariateSelect(_SklearnSelectorMixin, FeatureSelector):
    """scikit-learn GenericUnivariateSelect (hub key ``sklearn.GenericUnivariateSelect``).

    Wraps :class:`sklearn.feature_selection._univariate_selection.GenericUnivariateSelect`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['GenericUnivariateSelect']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'GenericUnivariateSelect')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_feature_selector(tags=['selection', 'feature-selection', 'sklearn-extended'])
class SelectFdr(_SklearnSelectorMixin, FeatureSelector):
    """scikit-learn SelectFdr (hub key ``sklearn.SelectFdr``).

    Wraps :class:`sklearn.feature_selection._univariate_selection.SelectFdr`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['SelectFdr']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'SelectFdr')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_feature_selector(tags=['selection', 'feature-selection', 'sklearn-extended'])
class SelectFpr(_SklearnSelectorMixin, FeatureSelector):
    """scikit-learn SelectFpr (hub key ``sklearn.SelectFpr``).

    Wraps :class:`sklearn.feature_selection._univariate_selection.SelectFpr`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['SelectFpr']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'SelectFpr')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_feature_selector(tags=['selection', 'feature-selection', 'sklearn-extended'])
class SelectFwe(_SklearnSelectorMixin, FeatureSelector):
    """scikit-learn SelectFwe (hub key ``sklearn.SelectFwe``).

    Wraps :class:`sklearn.feature_selection._univariate_selection.SelectFwe`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['SelectFwe']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'SelectFwe')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_feature_selector(tags=['selection', 'feature-selection'])
class SelectKBest(_SklearnSelectorMixin, FeatureSelector):
    """scikit-learn SelectKBest (hub key ``sklearn.SelectKBest``).

    Wraps :class:`sklearn.feature_selection._univariate_selection.SelectKBest`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: k, score_func.
    """

    _SPEC = _BY_NAME['SelectKBest']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'SelectKBest')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_feature_selector(tags=['selection', 'feature-selection'])
class SelectPercentile(_SklearnSelectorMixin, FeatureSelector):
    """scikit-learn SelectPercentile (hub key ``sklearn.SelectPercentile``).

    Wraps :class:`sklearn.feature_selection._univariate_selection.SelectPercentile`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: percentile, score_func.
    """

    _SPEC = _BY_NAME['SelectPercentile']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'SelectPercentile')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_feature_selector(tags=['selection', 'feature-selection'])
class VarianceThreshold(_SklearnSelectorMixin, FeatureSelector):
    """scikit-learn VarianceThreshold (hub key ``sklearn.VarianceThreshold``).

    Wraps :class:`sklearn.feature_selection._variance_threshold.VarianceThreshold`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: threshold.
    """

    _SPEC = _BY_NAME['VarianceThreshold']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'VarianceThreshold')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


__all__ = ['GenericUnivariateSelect', 'SelectFdr', 'SelectFpr', 'SelectFwe', 'SelectKBest', 'SelectPercentile', 'VarianceThreshold']
