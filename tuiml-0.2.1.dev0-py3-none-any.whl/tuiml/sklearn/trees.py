"""scikit-learn trees wrappers.

Generated from the ``TREES`` table in :mod:`tuiml.sklearn.specs`.
Registered under ``sklearn.<ClassName>`` hub keys, mirroring the native
TuiML ``trees`` family.
"""


from typing import Any, Dict, List

from tuiml.base.algorithms import Classifier, Regressor
from tuiml.sklearn._base import (
    _SklearnBackedMixin,
    sk_classifier,
    sk_regressor,
)
from tuiml.sklearn._spec import build_estimator, derive_schema

from tuiml.sklearn.specs import TREES as _SPECS

_BY_NAME = {s.name: s for s in _SPECS}


@sk_classifier(tags=['trees', 'tree'])
class DecisionTreeClassifier(_SklearnBackedMixin, Classifier):
    """scikit-learn DecisionTreeClassifier (hub key ``sklearn.DecisionTreeClassifier``).

    Wraps :class:`sklearn.tree._classes.DecisionTreeClassifier`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: criterion, max_depth, random_state.
    """

    _SPEC = _BY_NAME['DecisionTreeClassifier']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'DecisionTreeClassifier')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_classifier(tags=['trees', 'tree', 'sklearn-extended'])
class ExtraTreeClassifier(_SklearnBackedMixin, Classifier):
    """scikit-learn ExtraTreeClassifier (hub key ``sklearn.ExtraTreeClassifier``).

    Wraps :class:`sklearn.tree._classes.ExtraTreeClassifier`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['ExtraTreeClassifier']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'ExtraTreeClassifier')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_regressor(tags=['trees', 'tree'])
class DecisionTreeRegressor(_SklearnBackedMixin, Regressor):
    """scikit-learn DecisionTreeRegressor (hub key ``sklearn.DecisionTreeRegressor``).

    Wraps :class:`sklearn.tree._classes.DecisionTreeRegressor`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: criterion, max_depth, random_state.
    """

    _SPEC = _BY_NAME['DecisionTreeRegressor']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'DecisionTreeRegressor')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_regressor(tags=['trees', 'tree', 'sklearn-extended'])
class ExtraTreeRegressor(_SklearnBackedMixin, Regressor):
    """scikit-learn ExtraTreeRegressor (hub key ``sklearn.ExtraTreeRegressor``).

    Wraps :class:`sklearn.tree._classes.ExtraTreeRegressor`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['ExtraTreeRegressor']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'ExtraTreeRegressor')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


__all__ = ['DecisionTreeClassifier', 'ExtraTreeClassifier', 'DecisionTreeRegressor', 'ExtraTreeRegressor']
