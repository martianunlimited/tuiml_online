"""scikit-learn ensemble wrappers.

Generated from the ``ENSEMBLE`` table in :mod:`tuiml.sklearn.specs`.
Registered under ``sklearn.<ClassName>`` hub keys, mirroring the native
TuiML ``ensemble`` family.
"""


from typing import Any, Dict, List

from tuiml.base.algorithms import Classifier, Regressor
from tuiml.base.preprocessing import Transformer
from tuiml.sklearn._base import (
    _SklearnBackedMixin,
    _SklearnTransformerMixin,
    sk_classifier,
    sk_regressor,
    sk_transformer,
)
from tuiml.sklearn._spec import build_estimator, derive_schema

from tuiml.sklearn.specs import ENSEMBLE as _SPECS

_BY_NAME = {s.name: s for s in _SPECS}


@sk_classifier(tags=['ensemble'])
class AdaBoostClassifier(_SklearnBackedMixin, Classifier):
    """scikit-learn AdaBoostClassifier (hub key ``sklearn.AdaBoostClassifier``).

    Wraps :class:`sklearn.ensemble._weight_boosting.AdaBoostClassifier`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['AdaBoostClassifier']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'AdaBoostClassifier')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_classifier(tags=['ensemble'])
class BaggingClassifier(_SklearnBackedMixin, Classifier):
    """scikit-learn BaggingClassifier (hub key ``sklearn.BaggingClassifier``).

    Wraps :class:`sklearn.ensemble._bagging.BaggingClassifier`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['BaggingClassifier']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'BaggingClassifier')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_classifier(tags=['ensemble', 'tree'])
class ExtraTreesClassifier(_SklearnBackedMixin, Classifier):
    """scikit-learn ExtraTreesClassifier (hub key ``sklearn.ExtraTreesClassifier``).

    Wraps :class:`sklearn.ensemble._forest.ExtraTreesClassifier`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: n_estimators, max_depth, random_state.
    """

    _SPEC = _BY_NAME['ExtraTreesClassifier']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'ExtraTreesClassifier')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_classifier(tags=['ensemble', 'gradient-boosting'])
class GradientBoostingClassifier(_SklearnBackedMixin, Classifier):
    """scikit-learn GradientBoostingClassifier (hub key ``sklearn.GradientBoostingClassifier``).

    Wraps :class:`sklearn.ensemble._gb.GradientBoostingClassifier`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: n_estimators, learning_rate, max_depth.
    """

    _SPEC = _BY_NAME['GradientBoostingClassifier']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'GradientBoostingClassifier')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_classifier(tags=['ensemble', 'gradient-boosting'])
class HistGradientBoostingClassifier(_SklearnBackedMixin, Classifier):
    """scikit-learn HistGradientBoostingClassifier (hub key ``sklearn.HistGradientBoostingClassifier``).

    Wraps :class:`sklearn.ensemble._hist_gradient_boosting.gradient_boosting.HistGradientBoostingClassifier`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: learning_rate, max_iter, max_depth.
    """

    _SPEC = _BY_NAME['HistGradientBoostingClassifier']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'HistGradientBoostingClassifier')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_classifier(tags=['ensemble'])
class RandomForestClassifier(_SklearnBackedMixin, Classifier):
    """scikit-learn RandomForestClassifier (hub key ``sklearn.RandomForestClassifier``).

    Wraps :class:`sklearn.ensemble._forest.RandomForestClassifier`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: n_estimators, max_depth, random_state.
    """

    _SPEC = _BY_NAME['RandomForestClassifier']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'RandomForestClassifier')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_regressor(tags=['ensemble'])
class AdaBoostRegressor(_SklearnBackedMixin, Regressor):
    """scikit-learn AdaBoostRegressor (hub key ``sklearn.AdaBoostRegressor``).

    Wraps :class:`sklearn.ensemble._weight_boosting.AdaBoostRegressor`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['AdaBoostRegressor']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'AdaBoostRegressor')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_regressor(tags=['ensemble'])
class BaggingRegressor(_SklearnBackedMixin, Regressor):
    """scikit-learn BaggingRegressor (hub key ``sklearn.BaggingRegressor``).

    Wraps :class:`sklearn.ensemble._bagging.BaggingRegressor`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['BaggingRegressor']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'BaggingRegressor')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_regressor(tags=['ensemble', 'tree'])
class ExtraTreesRegressor(_SklearnBackedMixin, Regressor):
    """scikit-learn ExtraTreesRegressor (hub key ``sklearn.ExtraTreesRegressor``).

    Wraps :class:`sklearn.ensemble._forest.ExtraTreesRegressor`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: n_estimators, max_depth, random_state.
    """

    _SPEC = _BY_NAME['ExtraTreesRegressor']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'ExtraTreesRegressor')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_regressor(tags=['ensemble', 'gradient-boosting'])
class GradientBoostingRegressor(_SklearnBackedMixin, Regressor):
    """scikit-learn GradientBoostingRegressor (hub key ``sklearn.GradientBoostingRegressor``).

    Wraps :class:`sklearn.ensemble._gb.GradientBoostingRegressor`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: n_estimators, learning_rate, max_depth.
    """

    _SPEC = _BY_NAME['GradientBoostingRegressor']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'GradientBoostingRegressor')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_regressor(tags=['ensemble', 'gradient-boosting'])
class HistGradientBoostingRegressor(_SklearnBackedMixin, Regressor):
    """scikit-learn HistGradientBoostingRegressor (hub key ``sklearn.HistGradientBoostingRegressor``).

    Wraps :class:`sklearn.ensemble._hist_gradient_boosting.gradient_boosting.HistGradientBoostingRegressor`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: learning_rate, max_iter, max_depth.
    """

    _SPEC = _BY_NAME['HistGradientBoostingRegressor']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'HistGradientBoostingRegressor')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_regressor(tags=['ensemble'])
class RandomForestRegressor(_SklearnBackedMixin, Regressor):
    """scikit-learn RandomForestRegressor (hub key ``sklearn.RandomForestRegressor``).

    Wraps :class:`sklearn.ensemble._forest.RandomForestRegressor`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: n_estimators, max_depth, random_state.
    """

    _SPEC = _BY_NAME['RandomForestRegressor']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'RandomForestRegressor')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_transformer(tags=['ensemble', 'tree', 'sklearn-extended'])
class RandomTreesEmbedding(_SklearnTransformerMixin, Transformer):
    """scikit-learn RandomTreesEmbedding (hub key ``sklearn.RandomTreesEmbedding``).

    Wraps :class:`sklearn.ensemble._forest.RandomTreesEmbedding`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['RandomTreesEmbedding']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'RandomTreesEmbedding')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


__all__ = ['AdaBoostClassifier', 'BaggingClassifier', 'ExtraTreesClassifier', 'GradientBoostingClassifier', 'HistGradientBoostingClassifier', 'RandomForestClassifier', 'AdaBoostRegressor', 'BaggingRegressor', 'ExtraTreesRegressor', 'GradientBoostingRegressor', 'HistGradientBoostingRegressor', 'RandomForestRegressor', 'RandomTreesEmbedding']
