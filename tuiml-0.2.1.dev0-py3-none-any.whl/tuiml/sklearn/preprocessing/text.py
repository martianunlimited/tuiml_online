"""scikit-learn text wrappers.

Generated from the ``PREPROCESSING_TEXT`` table in :mod:`tuiml.sklearn.specs`.
Registered under ``sklearn.<ClassName>`` hub keys, mirroring the native
TuiML ``preprocessing/text`` family.
"""


from typing import Any, Dict, List

from tuiml.base.preprocessing import Transformer
from tuiml.sklearn._base import (
    _SklearnTransformerMixin,
    sk_transformer,
)
from tuiml.sklearn._spec import build_estimator, derive_schema

from tuiml.sklearn.specs import PREPROCESSING_TEXT as _SPECS

_BY_NAME = {s.name: s for s in _SPECS}


@sk_transformer(tags=['text', 'feature-extraction'])
class CountVectorizer(_SklearnTransformerMixin, Transformer):
    """scikit-learn CountVectorizer (hub key ``sklearn.CountVectorizer``).

    Wraps :class:`sklearn.feature_extraction.text.CountVectorizer`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: max_features, ngram_range, stop_words.
    """

    _SPEC = _BY_NAME['CountVectorizer']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'CountVectorizer')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_transformer(tags=['text', 'feature-extraction', 'sklearn-extended'])
class DictVectorizer(_SklearnTransformerMixin, Transformer):
    """scikit-learn DictVectorizer (hub key ``sklearn.DictVectorizer``).

    Wraps :class:`sklearn.feature_extraction._dict_vectorizer.DictVectorizer`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['DictVectorizer']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'DictVectorizer')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_transformer(tags=['text', 'feature-extraction', 'sklearn-extended'])
class FeatureHasher(_SklearnTransformerMixin, Transformer):
    """scikit-learn FeatureHasher (hub key ``sklearn.FeatureHasher``).

    Wraps :class:`sklearn.feature_extraction._hash.FeatureHasher`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['FeatureHasher']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'FeatureHasher')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_transformer(tags=['text', 'feature-extraction', 'sklearn-extended'])
class HashingVectorizer(_SklearnTransformerMixin, Transformer):
    """scikit-learn HashingVectorizer (hub key ``sklearn.HashingVectorizer``).

    Wraps :class:`sklearn.feature_extraction.text.HashingVectorizer`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['HashingVectorizer']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'HashingVectorizer')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_transformer(tags=['text', 'feature-extraction', 'sklearn-extended'])
class PatchExtractor(_SklearnTransformerMixin, Transformer):
    """scikit-learn PatchExtractor (hub key ``sklearn.PatchExtractor``).

    Wraps :class:`sklearn.feature_extraction.image.PatchExtractor`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['PatchExtractor']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'PatchExtractor')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_transformer(tags=['text', 'feature-extraction', 'sklearn-extended'])
class TfidfTransformer(_SklearnTransformerMixin, Transformer):
    """scikit-learn TfidfTransformer (hub key ``sklearn.TfidfTransformer``).

    Wraps :class:`sklearn.feature_extraction.text.TfidfTransformer`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.
    """

    _SPEC = _BY_NAME['TfidfTransformer']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'TfidfTransformer')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


@sk_transformer(tags=['text', 'feature-extraction'])
class TfidfVectorizer(_SklearnTransformerMixin, Transformer):
    """scikit-learn TfidfVectorizer (hub key ``sklearn.TfidfVectorizer``).

    Wraps :class:`sklearn.feature_extraction.text.TfidfVectorizer`. Accepts that
    estimator's constructor parameters as keyword arguments; call
    :meth:`get_parameter_schema` for the full list with types and
    defaults derived from the installed scikit-learn.

    Commonly set: max_features, ngram_range, stop_words.
    """

    _SPEC = _BY_NAME['TfidfVectorizer']

    def __init__(self, **params: Any):
        super().__init__()
        self._params = {**self._SPEC.defaults, **params}
        for key, value in self._params.items():
            setattr(self, key, value)

    def _build_estimator(self):
        """Construct the backing scikit-learn estimator."""
        return build_estimator(self._SPEC.target, self._params, 'TfidfVectorizer')

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Any]:
        """Return JSON Schema for constructor parameters."""
        return derive_schema(
            cls._SPEC.target, cls._SPEC.highlight, cls._SPEC.exclude
        )

    @classmethod
    def get_capabilities(cls) -> List[str]:
        """Return the capability names this wrapper supports."""
        return list(cls._SPEC.capabilities)


__all__ = ['CountVectorizer', 'DictVectorizer', 'FeatureHasher', 'HashingVectorizer', 'PatchExtractor', 'TfidfTransformer', 'TfidfVectorizer']
