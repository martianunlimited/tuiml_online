"""Parameter-Efficient Fine-Tuning (PEFT/LoRA) agent tools for TuiML.

Provides tools for AI agents to fine-tune low-rank adapters on-the-fly:
- Diffusion style adaptation (Stable Diffusion UNet cross-attention)
- Causal language model adaptation (Transformer self-attention)
"""

import gc
import json
import os
import time
from typing import Any, Dict, List, Optional

from ._spec import ToolSpec

_LOCAL_SD_CHECKPOINTS = [
    "/research/current_drive/automatic/models/Stable-diffusion/v1-5-pruned-emaonly.safetensors",
    os.path.expanduser("~/.cache/huggingface/hub/models--runwayml--stable-diffusion-v1-5"),
    os.path.expanduser("~/.cache/huggingface/hub/models--stable-diffusion-v1-5--stable-diffusion-v1-5"),
]


def _resolve_sd_model(requested_model: Optional[str]) -> str:
    """Find a locally cached SD 1.5 checkpoint or return hub ID."""
    if requested_model:
        return requested_model
    for path in _LOCAL_SD_CHECKPOINTS:
        if os.path.exists(path):
            return path
    return "stable-diffusion-v1-5/stable-diffusion-v1-5"


def execute_peft_train(**kwargs) -> Dict[str, Any]:
    """Train a low-rank adapter (LoRA) on multimodal or language models.

    Parameters
    ----------
    task_type : str, default='diffusion_style'
        Adaptation task: ``'diffusion_style'`` or ``'causal_lm'``.
    dataset : str
        Dataset identifier on Hugging Face Hub (e.g.
        ``'haidarazmi/lora-pixel-art-characters-datases'``) or path to a local directory/file.
    base_model : str, optional
        Base model name or checkpoint path. Defaults to Stable Diffusion 1.5 for
        ``'diffusion_style'`` or Qwen/Qwen2.5-0.5B-Instruct for ``'causal_lm'``.
    lora_rank : int, default=8
        Inner bottleneck rank ($r$) for low-rank decomposition.
    lora_alpha : int, default=8
        LoRA scaling multiplier ($\alpha$).
    epochs : int, default=5
        Number of training epochs.
    batch_size : int, default=1
        Per-device batch size.
    learning_rate : float, default=2e-4
        AdamW learning rate.
    max_samples : int, default=32
        Maximum training samples to draw from the dataset.
    target_modules : list of str, optional
        Target projection layer names (defaults to cross-attention for diffusion
        or attention projections for language models).
    output_dir : str, optional
        Directory where adapter weights will be saved. Defaults to ``~/.tuiml/adapters``.
    adapter_name : str, optional
        Name of the adapter file (without extension). Defaults to auto-generated timestamp.
    _progress_callback : callable, default=None
        Optional progress callback hook for MCP client streaming.

    Returns
    -------
    dict
        Status, adapter path, parameter counts, and training dynamics.
    """
    progress_callback = kwargs.pop("_progress_callback", None)
    task_type = kwargs.get("task_type", "diffusion_style")
    dataset_name = kwargs.get("dataset")

    if not dataset_name:
        return {"status": "error", "error": "'dataset' argument is required."}

    t0 = time.time()

    def _emit_progress(epoch: int, total_epochs: int, loss: float, phase: str = "training") -> None:
        if progress_callback:
            progress_callback({
                "type": "peft_progress",
                "phase": phase,
                "epoch": epoch,
                "total_epochs": total_epochs,
                "loss": round(loss, 5),
            })

    try:
        import numpy as np
        import torch
        from peft import LoraConfig, get_peft_model_state_dict
        from safetensors.torch import save_file

        device = "cuda" if torch.cuda.is_available() else "cpu"
        out_dir = kwargs.get("output_dir") or os.path.expanduser("~/.tuiml/adapters")
        os.makedirs(out_dir, exist_ok=True)
        adapter_name = kwargs.get("adapter_name") or f"{task_type}_lora_{int(time.time())}"
        adapter_path = os.path.join(out_dir, f"{adapter_name}.safetensors")

        lora_rank = int(kwargs.get("lora_rank", 8))
        lora_alpha = int(kwargs.get("lora_alpha", 8))
        epochs = max(1, int(kwargs.get("epochs", 5)))
        batch_size = max(1, int(kwargs.get("batch_size", 1)))
        learning_rate = float(kwargs.get("learning_rate", 2e-4))
        max_samples = max(1, int(kwargs.get("max_samples", 32)))

        if task_type == "diffusion_style":
            from datasets import load_dataset
            from diffusers import StableDiffusionPipeline

            base_model = _resolve_sd_model(kwargs.get("base_model"))
            target_modules = kwargs.get("target_modules") or ["to_k", "to_q", "to_v", "to_out.0"]

            _emit_progress(0, epochs, 0.0, phase="loading_pipeline")
            pipe = StableDiffusionPipeline.from_pretrained(
                base_model,
                torch_dtype=torch.float16 if device == "cuda" else torch.float32,
                safety_checker=None,
            )
            if device == "cuda":
                pipe = pipe.to(device)

            lora_config = LoraConfig(
                r=lora_rank,
                lora_alpha=lora_alpha,
                init_lora_weights="gaussian",
                target_modules=target_modules,
            )
            pipe.unet.add_adapter(lora_config)

            # Ensure trainable weights are float32 for optimizer stability
            for n, p in pipe.unet.named_parameters():
                if p.requires_grad:
                    p.data = p.data.to(torch.float32)

            trainable_params = sum(p.numel() for p in pipe.unet.parameters() if p.requires_grad)
            total_params = sum(p.numel() for p in pipe.unet.parameters())
            pct_trainable = (trainable_params / total_params) * 100

            # Pre-cache training dataset latents and text embeddings
            _emit_progress(0, epochs, 0.0, phase="caching_latents")
            split_spec = f"train[:{max_samples}]"
            ds = load_dataset(dataset_name, split=split_spec)

            cached_latents = []
            cached_text_embeds = []
            pipe.vae.eval()
            pipe.text_encoder.eval()

            dtype = torch.float16 if device == "cuda" else torch.float32
            with torch.no_grad():
                for item in ds:
                    img = item["image"].convert("RGB").resize((512, 512))
                    arr = (np.array(img, dtype=np.float32) / 127.5) - 1.0
                    tensor = torch.from_numpy(arr).permute(2, 0, 1).unsqueeze(0).to(device, dtype=dtype)
                    latent = pipe.vae.encode(tensor).latent_dist.sample() * pipe.vae.config.scaling_factor
                    cached_latents.append(latent)

                    prompt_text = item.get("prompt", "character sprite")
                    prompt_ids = pipe.tokenizer(
                        prompt_text,
                        truncation=True,
                        max_length=pipe.tokenizer.model_max_length,
                        padding="max_length",
                        return_tensors="pt",
                    ).input_ids.to(device)
                    text_embed = pipe.text_encoder(prompt_ids)[0]
                    cached_text_embeds.append(text_embed)

            # Offload VAE and text encoder to CPU during UNet backward pass
            if device == "cuda":
                pipe.vae.to("cpu")
                pipe.text_encoder.to("cpu")
                gc.collect()
                torch.cuda.empty_cache()
                pipe.unet.enable_gradient_checkpointing()

            pipe.unet.enable_adapters()
            pipe.unet.train()

            optimizer = torch.optim.AdamW(
                filter(lambda p: p.requires_grad, pipe.unet.parameters()),
                lr=learning_rate,
                weight_decay=0.01,
            )

            loss_history = []
            n_samples = len(cached_latents)
            grad_accum_steps = 2

            for ep in range(epochs):
                ep_loss = 0.0
                perm = torch.randperm(n_samples)
                batches = [perm[i:i + batch_size] for i in range(0, n_samples, batch_size)]
                optimizer.zero_grad()

                for step_idx, b_indices in enumerate(batches):
                    b_latents = torch.cat([cached_latents[i] for i in b_indices], dim=0)
                    b_embeds = torch.cat([cached_text_embeds[i] for i in b_indices], dim=0)

                    noise = torch.randn_like(b_latents)
                    timesteps = torch.randint(
                        0,
                        pipe.scheduler.config.num_train_timesteps,
                        (b_latents.shape[0],),
                        device=device,
                    ).long()
                    noisy_latents = pipe.scheduler.add_noise(b_latents, noise, timesteps)

                    if device == "cuda":
                        with torch.amp.autocast("cuda", dtype=torch.float16):
                            noise_pred = pipe.unet(
                                noisy_latents,
                                timesteps,
                                encoder_hidden_states=b_embeds,
                            ).sample
                            loss = torch.nn.functional.mse_loss(noise_pred.float(), noise.float())
                            loss = loss / grad_accum_steps
                    else:
                        noise_pred = pipe.unet(
                            noisy_latents,
                            timesteps,
                            encoder_hidden_states=b_embeds,
                        ).sample
                        loss = torch.nn.functional.mse_loss(noise_pred, noise)
                        loss = loss / grad_accum_steps

                    loss.backward()

                    if (step_idx + 1) % grad_accum_steps == 0 or (step_idx + 1) == len(batches):
                        optimizer.step()
                        optimizer.zero_grad()
                    ep_loss += loss.item() * grad_accum_steps

                avg_loss = ep_loss / len(batches)
                loss_history.append(avg_loss)
                _emit_progress(ep + 1, epochs, avg_loss)

            # Save adapter weights
            lora_state_dict = get_peft_model_state_dict(pipe.unet)
            save_file(lora_state_dict, adapter_path)
            adapter_size = os.path.getsize(adapter_path)

            peak_vram = round(torch.cuda.max_memory_allocated() / (1024 ** 2), 1) if device == "cuda" else 0.0
            duration = round(time.time() - t0, 2)

            del pipe
            gc.collect()
            if device == "cuda":
                torch.cuda.empty_cache()

            return {
                "status": "success",
                "adapter_path": os.path.abspath(adapter_path),
                "adapter_name": adapter_name,
                "task_type": task_type,
                "base_model": base_model,
                "dataset": dataset_name,
                "samples_trained": n_samples,
                "epochs": epochs,
                "lora_rank": lora_rank,
                "lora_alpha": lora_alpha,
                "trainable_params": trainable_params,
                "total_params": total_params,
                "pct_trainable": round(pct_trainable, 4),
                "adapter_size_bytes": adapter_size,
                "initial_loss": round(loss_history[0], 5),
                "final_loss": round(loss_history[-1], 5),
                "duration_seconds": duration,
                "peak_vram_mb": peak_vram,
            }

        elif task_type in ("causal_lm", "text_generation", "text_qa"):
            from datasets import load_dataset
            from transformers import AutoModelForCausalLM, AutoTokenizer

            base_model = kwargs.get("base_model") or "Qwen/Qwen2.5-0.5B-Instruct"
            target_modules = kwargs.get("target_modules") or ["q_proj", "v_proj"]

            _emit_progress(0, epochs, 0.0, phase="loading_pipeline")
            tokenizer = AutoTokenizer.from_pretrained(base_model, trust_remote_code=True)
            if tokenizer.pad_token is None:
                tokenizer.pad_token = tokenizer.eos_token

            model = AutoModelForCausalLM.from_pretrained(
                base_model,
                torch_dtype=torch.float16 if device == "cuda" else torch.float32,
                trust_remote_code=True,
            )
            if device == "cuda":
                model = model.to(device)

            lora_config = LoraConfig(
                r=lora_rank,
                lora_alpha=lora_alpha,
                target_modules=target_modules,
                task_type="CAUSAL_LM",
            )
            from peft import get_peft_model
            peft_model = get_peft_model(model, lora_config)

            trainable_params = sum(p.numel() for p in peft_model.parameters() if p.requires_grad)
            total_params = sum(p.numel() for p in peft_model.parameters())
            pct_trainable = (trainable_params / total_params) * 100

            # Load dataset
            ds = load_dataset(dataset_name, split=f"train[:{max_samples}]")
            texts = []
            for item in ds:
                if "text" in item:
                    texts.append(item["text"])
                elif "prompt" in item and "response" in item:
                    texts.append(f"User: {item['prompt']}\nAssistant: {item['response']}")
                elif "question" in item and "context" in item:
                    texts.append(f"Context: {item['context']}\nQuestion: {item['question']}")
                else:
                    texts.append(str(item))

            inputs = tokenizer(
                texts,
                padding=True,
                truncation=True,
                max_length=256,
                return_tensors="pt",
            ).to(device)

            optimizer = torch.optim.AdamW(
                filter(lambda p: p.requires_grad, peft_model.parameters()),
                lr=learning_rate,
            )

            loss_history = []
            peft_model.train()
            n_samples = len(texts)

            for ep in range(epochs):
                optimizer.zero_grad()
                outputs = peft_model(
                    input_ids=inputs.input_ids,
                    attention_mask=inputs.attention_mask,
                    labels=inputs.input_ids,
                )
                loss = outputs.loss
                loss.backward()
                optimizer.step()
                ep_loss = loss.item()
                loss_history.append(ep_loss)
                _emit_progress(ep + 1, epochs, ep_loss)

            peft_model.save_pretrained(out_dir)
            adapter_weights_path = os.path.join(out_dir, "adapter_model.safetensors")
            if not os.path.exists(adapter_weights_path):
                # Fallback to direct state dict save
                lora_state_dict = get_peft_model_state_dict(peft_model)
                save_file(lora_state_dict, adapter_path)
            else:
                adapter_path = adapter_weights_path

            adapter_size = os.path.getsize(adapter_path)
            peak_vram = round(torch.cuda.max_memory_allocated() / (1024 ** 2), 1) if device == "cuda" else 0.0
            duration = round(time.time() - t0, 2)

            del peft_model
            del model
            gc.collect()
            if device == "cuda":
                torch.cuda.empty_cache()

            return {
                "status": "success",
                "adapter_path": os.path.abspath(adapter_path),
                "adapter_name": adapter_name,
                "task_type": task_type,
                "base_model": base_model,
                "dataset": dataset_name,
                "samples_trained": n_samples,
                "epochs": epochs,
                "lora_rank": lora_rank,
                "lora_alpha": lora_alpha,
                "trainable_params": trainable_params,
                "total_params": total_params,
                "pct_trainable": round(pct_trainable, 4),
                "adapter_size_bytes": adapter_size,
                "initial_loss": round(loss_history[0], 5),
                "final_loss": round(loss_history[-1], 5),
                "duration_seconds": duration,
                "peak_vram_mb": peak_vram,
            }
        else:
            return {
                "status": "error",
                "error": f"Unsupported task_type '{task_type}'. Use 'diffusion_style' or 'causal_lm'.",
            }

    except Exception as e:
        return {"status": "error", "error": str(e)}


PEFT_TRAIN_SPEC = ToolSpec(
    name="tuiml_peft_train",
    description="Fine-tune a lightweight Low-Rank Adapter (LoRA) on multimodal diffusion models (styles) or language models. Saves a compact .safetensors adapter file for instant inference.",
    input_schema={
        "type": "object",
        "properties": {
            "dataset": {
                "type": "string",
                "description": "Hugging Face dataset identifier (e.g. 'haidarazmi/lora-pixel-art-characters-datases') or local path",
            },
            "task_type": {
                "type": "string",
                "enum": ["diffusion_style", "causal_lm"],
                "default": "diffusion_style",
                "description": "Adaptation task: 'diffusion_style' (SD 1.5 UNet) or 'causal_lm' (transformer autoregressive)",
            },
            "base_model": {
                "type": "string",
                "description": "Optional base model ID or path. Defaults to Stable Diffusion 1.5 for diffusion or Qwen for causal_lm",
            },
            "lora_rank": {
                "type": "integer",
                "default": 8,
                "description": "LoRA rank (bottleneck dimension r)",
            },
            "lora_alpha": {
                "type": "integer",
                "default": 8,
                "description": "LoRA scaling alpha multiplier",
            },
            "epochs": {
                "type": "integer",
                "default": 5,
                "description": "Number of training epochs (default 5)",
            },
            "batch_size": {
                "type": "integer",
                "default": 1,
                "description": "Batch size per device",
            },
            "learning_rate": {
                "type": "number",
                "default": 2e-4,
                "description": "AdamW learning rate",
            },
            "max_samples": {
                "type": "integer",
                "default": 32,
                "description": "Maximum training samples to draw from dataset",
            },
            "target_modules": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Target projection module names to adapt",
            },
            "output_dir": {
                "type": "string",
                "description": "Directory to save adapter weights (defaults to ~/.tuiml/adapters)",
            },
            "adapter_name": {
                "type": "string",
                "description": "Base filename for saved adapter (without .safetensors)",
            },
        },
        "required": ["dataset"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "adapter_path": {"type": "string"},
            "adapter_name": {"type": "string"},
            "task_type": {"type": "string"},
            "base_model": {"type": "string"},
            "dataset": {"type": "string"},
            "samples_trained": {"type": "integer"},
            "epochs": {"type": "integer"},
            "lora_rank": {"type": "integer"},
            "lora_alpha": {"type": "integer"},
            "trainable_params": {"type": "integer"},
            "total_params": {"type": "integer"},
            "pct_trainable": {"type": "number"},
            "adapter_size_bytes": {"type": "integer"},
            "initial_loss": {"type": "number"},
            "final_loss": {"type": "number"},
            "duration_seconds": {"type": "number"},
            "peak_vram_mb": {"type": "number"},
            "error": {"type": "string"},
        },
        "required": ["status"],
    },
    execute=execute_peft_train,
    group="workflow",
    read_only=False,
    open_world=True,
)
