"""Hugging Face multimodal and generative tools for AI agents:
- Image generation via Stable Diffusion (SD 1.5)
- Vision-Language analysis & captioning (BLIP)
- Visual Question Answering (ViLT)
- Text generation (Causal LM)
- Text embeddings extraction
"""

import base64
import io
import os
import time
from typing import Any, Dict, List, Optional
from PIL import Image

from ._spec import ToolSpec

_LOCAL_SD_CHECKPOINTS = [
    "/research/current_drive/automatic/models/Stable-diffusion/v1-5-pruned-emaonly.safetensors",
    os.path.expanduser("~/.cache/huggingface/hub/models--runwayml--stable-diffusion-v1-5"),
]


def _get_default_sd_checkpoint() -> str:
    """Find a locally available SD 1.5 checkpoint or return hub ID."""
    for path in _LOCAL_SD_CHECKPOINTS:
        if os.path.exists(path):
            return path
    return "runwayml/stable-diffusion-v1-5"


# -----------------------------------------------------------------------------
# 1. Image Generation (Stable Diffusion)
# -----------------------------------------------------------------------------

def execute_hf_generate_image(**kwargs) -> Dict[str, Any]:
    """Generate images from text prompts using Stable Diffusion."""
    try:
        import torch
        from diffusers import StableDiffusionPipeline

        prompt = kwargs.get("prompt")
        if not prompt:
            return {"status": "error", "error": "'prompt' is required."}

        negative_prompt = kwargs.get("negative_prompt", "blurry, low quality, distorted, bad anatomy")
        num_inference_steps = kwargs.get("num_inference_steps", 20)
        guidance_scale = kwargs.get("guidance_scale", 7.5)
        width = kwargs.get("width", 512)
        height = kwargs.get("height", 512)
        seed = kwargs.get("seed")
        output_path = kwargs.get("output_path")
        model = kwargs.get("model") or _get_default_sd_checkpoint()

        torch.cuda.empty_cache()
        t0 = time.time()

        device = "cuda" if torch.cuda.is_available() else "cpu"
        torch_dtype = torch.float16 if device == "cuda" else torch.float32

        if os.path.isfile(model) and model.endswith((".safetensors", ".ckpt")):
            pipe = StableDiffusionPipeline.from_single_file(
                model,
                torch_dtype=torch_dtype,
                safety_checker=None,
            )
        else:
            pipe = StableDiffusionPipeline.from_pretrained(
                model,
                torch_dtype=torch_dtype,
                safety_checker=None,
            )

        pipe = pipe.to(device)

        lora_path = kwargs.get("lora_path")
        if lora_path and os.path.exists(lora_path):
            from peft import LoraConfig, set_peft_model_state_dict
            from safetensors.torch import load_file

            lora_config = LoraConfig(
                r=8,
                lora_alpha=8,
                init_lora_weights="gaussian",
                target_modules=["to_k", "to_q", "to_v", "to_out.0"],
            )
            pipe.unet.add_adapter(lora_config)
            adapter_weights = load_file(lora_path)
            set_peft_model_state_dict(pipe.unet, adapter_weights)
            pipe.unet.eval()
            pipe.unet.enable_adapters()

        generator = None
        if seed is not None:
            generator = torch.Generator(device=device).manual_seed(seed)

        output = pipe(
            prompt,
            negative_prompt=negative_prompt,
            num_inference_steps=num_inference_steps,
            guidance_scale=guidance_scale,
            width=width,
            height=height,
            generator=generator,
        )
        image = output.images[0]

        if not output_path:
            out_dir = os.path.expanduser("~/.tuiml/generated_images")
            os.makedirs(out_dir, exist_ok=True)
            output_path = os.path.join(out_dir, f"sd15_{int(time.time())}.png")
        else:
            os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

        image.save(output_path)

        # Base64 encode for MCP ImageContent delivery
        buf = io.BytesIO()
        image.save(buf, format="PNG")
        b64_data = base64.b64encode(buf.getvalue()).decode("utf-8")

        duration = round(time.time() - t0, 2)
        peak_vram = round(torch.cuda.max_memory_allocated() / (1024**2), 1) if device == "cuda" else 0.0

        del pipe
        del output
        torch.cuda.empty_cache()

        return {
            "status": "success",
            "image_path": os.path.abspath(output_path),
            "prompt": prompt,
            "width": width,
            "height": height,
            "steps": num_inference_steps,
            "model": model,
            "time_seconds": duration,
            "peak_vram_mb": peak_vram,
            "_image_base64": b64_data,
            "_image_mime": "image/png",
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


GENERATE_IMAGE_SPEC = ToolSpec(
    name="tuiml_hf_generate_image",
    description="Generate images from text prompts using Stable Diffusion (SD 1.5). Returns image file path and inline visual preview.",
    input_schema={
        "type": "object",
        "properties": {
            "prompt": {
                "type": "string",
                "description": "Text prompt describing the desired image",
            },
            "negative_prompt": {
                "type": "string",
                "default": "blurry, low quality, distorted, bad anatomy",
                "description": "Things to avoid in the generation",
            },
            "num_inference_steps": {
                "type": "integer",
                "default": 20,
                "description": "Number of denoising steps",
            },
            "guidance_scale": {
                "type": "number",
                "default": 7.5,
                "description": "Classifier-free guidance strength",
            },
            "width": {"type": "integer", "default": 512},
            "height": {"type": "integer", "default": 512},
            "seed": {"type": "integer", "description": "Optional random seed for reproducibility"},
            "output_path": {"type": "string", "description": "Optional file path to save the generated PNG"},
            "model": {"type": "string", "description": "Model ID or local checkpoint path (defaults to SD 1.5)"},
            "lora_path": {"type": "string", "description": "Optional path to trained LoRA adapter (.safetensors)"},
            "lora_scale": {"type": "number", "default": 1.0, "description": "LoRA adapter influence scaling factor"},
        },
        "required": ["prompt"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "image_path": {"type": "string"},
            "prompt": {"type": "string"},
            "width": {"type": "integer"},
            "height": {"type": "integer"},
            "steps": {"type": "integer"},
            "model": {"type": "string"},
            "time_seconds": {"type": "number"},
            "peak_vram_mb": {"type": "number"},
            "error": {"type": "string"},
        },
        "required": ["status"],
    },
    execute=execute_hf_generate_image,
    group="workflow",
    read_only=False,
    destructive=False,
    idempotent=False,
    open_world=True,
    reproducible=True,
)


# -----------------------------------------------------------------------------
# 2. Vision-Language Analysis & Captioning (VLM via BLIP)
# -----------------------------------------------------------------------------

def execute_hf_vlm_analyze(**kwargs) -> Dict[str, Any]:
    """Generate image captions or visual descriptions using a Vision-Language Model."""
    try:
        import torch
        from transformers import BlipProcessor, BlipForConditionalGeneration

        image_path = kwargs.get("image_path")
        if not image_path or not os.path.exists(image_path):
            return {"status": "error", "error": f"Invalid or missing image_path: {image_path}"}

        model_name = kwargs.get("model", "Salesforce/blip-image-captioning-base")
        prompt = kwargs.get("prompt")
        max_new_tokens = kwargs.get("max_new_tokens", 35)

        t0 = time.time()
        device = "cuda" if torch.cuda.is_available() else "cpu"

        processor = BlipProcessor.from_pretrained(model_name)
        model = BlipForConditionalGeneration.from_pretrained(model_name).to(device)

        img = Image.open(image_path).convert("RGB")
        if prompt:
            inputs = processor(img, prompt, return_tensors="pt").to(device)
        else:
            inputs = processor(img, return_tensors="pt").to(device)

        with torch.no_grad():
            out = model.generate(**inputs, max_new_tokens=max_new_tokens)
        caption = processor.decode(out[0], skip_special_tokens=True)

        duration = round(time.time() - t0, 2)
        del model
        del processor
        torch.cuda.empty_cache()

        return {
            "status": "success",
            "caption": caption,
            "image_path": os.path.abspath(image_path),
            "model": model_name,
            "time_seconds": duration,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


VLM_ANALYZE_SPEC = ToolSpec(
    name="tuiml_hf_vlm_analyze",
    description="Analyze an image and generate natural language descriptions / captions using a Vision-Language Model (BLIP).",
    input_schema={
        "type": "object",
        "properties": {
            "image_path": {"type": "string", "description": "Path to the input image file"},
            "prompt": {"type": "string", "description": "Optional prompt to guide caption generation"},
            "model": {"type": "string", "default": "Salesforce/blip-image-captioning-base"},
            "max_new_tokens": {"type": "integer", "default": 35},
        },
        "required": ["image_path"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "caption": {"type": "string"},
            "image_path": {"type": "string"},
            "model": {"type": "string"},
            "time_seconds": {"type": "number"},
            "error": {"type": "string"},
        },
        "required": ["status"],
    },
    execute=execute_hf_vlm_analyze,
    group="analysis",
    read_only=True,
    destructive=False,
    idempotent=True,
    open_world=False,
    reproducible=False,
)


# -----------------------------------------------------------------------------
# 3. Visual Question Answering (VQA via ViLT)
# -----------------------------------------------------------------------------

def execute_hf_vqa(**kwargs) -> Dict[str, Any]:
    """Answer natural language questions about an image using ViLT."""
    try:
        import torch
        from transformers import ViltProcessor, ViltForQuestionAnswering

        image_path = kwargs.get("image_path")
        if not image_path or not os.path.exists(image_path):
            return {"status": "error", "error": f"Invalid or missing image_path: {image_path}"}

        question = kwargs.get("question")
        if not question:
            return {"status": "error", "error": "'question' is required."}

        model_name = kwargs.get("model", "dandelin/vilt-b32-finetuned-vqa")
        top_k = kwargs.get("top_k", 3)

        t0 = time.time()
        device = "cuda" if torch.cuda.is_available() else "cpu"

        processor = ViltProcessor.from_pretrained(model_name)
        model = ViltForQuestionAnswering.from_pretrained(model_name).to(device)

        img = Image.open(image_path).convert("RGB")
        encoding = processor(img, question, return_tensors="pt").to(device)

        with torch.no_grad():
            outputs = model(**encoding)

        logits = outputs.logits[0]
        probs = torch.softmax(logits, dim=-1)
        top_indices = torch.topk(probs, k=min(top_k, len(probs))).indices.tolist()

        top_answers = [
            {
                "answer": model.config.id2label[idx],
                "confidence": round(probs[idx].item(), 4),
            }
            for idx in top_indices
        ]

        best_answer = top_answers[0]["answer"]
        best_conf = top_answers[0]["confidence"]

        duration = round(time.time() - t0, 2)
        del model
        del processor
        torch.cuda.empty_cache()

        return {
            "status": "success",
            "question": question,
            "answer": best_answer,
            "confidence": best_conf,
            "top_answers": top_answers,
            "image_path": os.path.abspath(image_path),
            "model": model_name,
            "time_seconds": duration,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


VQA_SPEC = ToolSpec(
    name="tuiml_hf_vqa",
    description="Answer natural language questions about an image using Visual Question Answering (ViLT).",
    input_schema={
        "type": "object",
        "properties": {
            "image_path": {"type": "string", "description": "Path to the input image file"},
            "question": {"type": "string", "description": "Question to ask about the image"},
            "model": {"type": "string", "default": "dandelin/vilt-b32-finetuned-vqa"},
            "top_k": {"type": "integer", "default": 3},
        },
        "required": ["image_path", "question"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "question": {"type": "string"},
            "answer": {"type": "string"},
            "confidence": {"type": "number"},
            "top_answers": {"type": "array", "items": {"type": "object"}},
            "image_path": {"type": "string"},
            "model": {"type": "string"},
            "time_seconds": {"type": "number"},
            "error": {"type": "string"},
        },
        "required": ["status"],
    },
    execute=execute_hf_vqa,
    group="analysis",
    read_only=True,
    destructive=False,
    idempotent=True,
    open_world=False,
    reproducible=False,
)


# -----------------------------------------------------------------------------
# 4. Text Generation (Causal LM via GPT-2 / Hugging Face models)
# -----------------------------------------------------------------------------

def execute_hf_text_generate(**kwargs) -> Dict[str, Any]:
    """Generate text completions using a Hugging Face Causal Language Model."""
    try:
        import torch
        from transformers import pipeline

        prompt = kwargs.get("prompt")
        if not prompt:
            return {"status": "error", "error": "'prompt' is required."}

        model_name = kwargs.get("model", "gpt2")
        max_new_tokens = kwargs.get("max_new_tokens", 50)
        temperature = kwargs.get("temperature", 0.7)
        do_sample = kwargs.get("do_sample", True)

        t0 = time.time()
        device = "cuda" if torch.cuda.is_available() else "cpu"

        pipe = pipeline("text-generation", model=model_name, device=device)
        res = pipe(
            prompt,
            max_new_tokens=max_new_tokens,
            num_return_sequences=1,
            do_sample=do_sample,
            temperature=temperature,
        )

        generated_text = res[0]["generated_text"]
        duration = round(time.time() - t0, 2)

        del pipe
        torch.cuda.empty_cache()

        return {
            "status": "success",
            "prompt": prompt,
            "generated_text": generated_text,
            "model": model_name,
            "time_seconds": duration,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


TEXT_GENERATE_SPEC = ToolSpec(
    name="tuiml_hf_text_generate",
    description="Generate text completions using a Hugging Face Causal Language Model (e.g., GPT-2).",
    input_schema={
        "type": "object",
        "properties": {
            "prompt": {"type": "string", "description": "Input prompt to continue"},
            "model": {"type": "string", "default": "gpt2"},
            "max_new_tokens": {"type": "integer", "default": 50},
            "temperature": {"type": "number", "default": 0.7},
            "do_sample": {"type": "boolean", "default": True},
        },
        "required": ["prompt"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "prompt": {"type": "string"},
            "generated_text": {"type": "string"},
            "model": {"type": "string"},
            "time_seconds": {"type": "number"},
            "error": {"type": "string"},
        },
        "required": ["status"],
    },
    execute=execute_hf_text_generate,
    group="workflow",
    read_only=False,
    destructive=False,
    idempotent=False,
    open_world=False,
    reproducible=True,
)


# -----------------------------------------------------------------------------
# 5. Text Embeddings Extraction
# -----------------------------------------------------------------------------

def execute_hf_embed_text(**kwargs) -> Dict[str, Any]:
    """Extract dense semantic embeddings from texts using HFTextEmbedder."""
    try:
        from tuiml.preprocessing.text.embeddings import HFTextEmbedder

        texts = kwargs.get("texts")
        if not texts or not isinstance(texts, list):
            return {"status": "error", "error": "'texts' must be a non-empty list of strings."}

        model_name = kwargs.get("model", "sentence-transformers/all-MiniLM-L6-v2")
        normalize = kwargs.get("normalize", True)
        batch_size = kwargs.get("batch_size", 32)

        t0 = time.time()
        embedder = HFTextEmbedder(
            model_name=model_name,
            normalize=normalize,
            batch_size=batch_size,
        )
        embedder.fit(texts)
        embeddings = embedder.transform(texts)
        duration = round(time.time() - t0, 2)

        return {
            "status": "success",
            "n_samples": len(texts),
            "embedding_dim": embedder.n_features_out_,
            "embeddings": embeddings.tolist(),
            "model": model_name,
            "time_seconds": duration,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


EMBED_TEXT_SPEC = ToolSpec(
    name="tuiml_hf_embed_text",
    description="Generate dense semantic embeddings for a list of text strings using Hugging Face transformers.",
    input_schema={
        "type": "object",
        "properties": {
            "texts": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of text documents to embed",
            },
            "model": {
                "type": "string",
                "default": "sentence-transformers/all-MiniLM-L6-v2",
                "description": "Pretrained model name or path",
            },
            "normalize": {
                "type": "boolean",
                "default": True,
                "description": "Whether to L2-normalize embeddings to unit length",
            },
            "batch_size": {
                "type": "integer",
                "default": 32,
                "description": "Batch size for tokenization and inference",
            },
        },
        "required": ["texts"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "n_samples": {"type": "integer"},
            "embedding_dim": {"type": "integer"},
            "embeddings": {"type": "array", "items": {"type": "array", "items": {"type": "number"}}},
            "model": {"type": "string"},
            "time_seconds": {"type": "number"},
            "error": {"type": "string"},
        },
        "required": ["status"],
    },
    execute=execute_hf_embed_text,
    group="workflow",
    read_only=True,
    destructive=False,
    idempotent=True,
    open_world=False,
    reproducible=True,
)


# -----------------------------------------------------------------------------
# 6. Image Embeddings Extraction (Vision for Tabular / Classical ML)
# -----------------------------------------------------------------------------

def execute_hf_embed_image(**kwargs) -> Dict[str, Any]:
    """Extract dense semantic embeddings from images using HFImageEmbedder."""
    try:
        from tuiml.preprocessing.vision.embeddings import HFImageEmbedder

        image_paths = kwargs.get("image_paths")
        if not image_paths or not isinstance(image_paths, list):
            return {"status": "error", "error": "'image_paths' must be a non-empty list of file paths."}

        for path in image_paths:
            if not os.path.exists(path):
                return {"status": "error", "error": f"Image file not found: {path}"}

        model_name = kwargs.get("model", "google/vit-base-patch16-224")
        normalize = kwargs.get("normalize", True)
        batch_size = kwargs.get("batch_size", 16)
        pooling = kwargs.get("pooling", "mean")

        t0 = time.time()
        embedder = HFImageEmbedder(
            model_name=model_name,
            normalize=normalize,
            batch_size=batch_size,
            pooling=pooling,
        )
        embedder.fit(image_paths)
        embeddings = embedder.transform(image_paths)
        duration = round(time.time() - t0, 2)

        return {
            "status": "success",
            "n_samples": len(image_paths),
            "embedding_dim": embedder.n_features_out_,
            "embeddings": embeddings.tolist(),
            "model": model_name,
            "time_seconds": duration,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


EMBED_IMAGE_SPEC = ToolSpec(
    name="tuiml_hf_embed_image",
    description="Generate dense semantic embeddings for a list of image files using Hugging Face vision transformers (ViT, ResNet, CLIP).",
    input_schema={
        "type": "object",
        "properties": {
            "image_paths": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of image file paths to embed",
            },
            "model": {
                "type": "string",
                "default": "google/vit-base-patch16-224",
                "description": "Pretrained vision model name or checkpoint path",
            },
            "pooling": {
                "type": "string",
                "default": "mean",
                "description": "Pooling strategy: 'mean', 'cls', or 'pooler'",
            },
            "normalize": {
                "type": "boolean",
                "default": True,
                "description": "Whether to L2-normalize embeddings to unit length",
            },
            "batch_size": {
                "type": "integer",
                "default": 16,
                "description": "Batch size for image processing and inference",
            },
        },
        "required": ["image_paths"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "n_samples": {"type": "integer"},
            "embedding_dim": {"type": "integer"},
            "embeddings": {"type": "array", "items": {"type": "array", "items": {"type": "number"}}},
            "model": {"type": "string"},
            "time_seconds": {"type": "number"},
            "error": {"type": "string"},
        },
        "required": ["status"],
    },
    execute=execute_hf_embed_image,
    group="workflow",
    read_only=True,
    destructive=False,
    idempotent=True,
    open_world=False,
    reproducible=True,
)


# -----------------------------------------------------------------------------
# 7. Zero-Shot Text Classification
# -----------------------------------------------------------------------------

def execute_hf_zero_shot_classify(**kwargs) -> Dict[str, Any]:
    """Classify text sequences into arbitrary candidate labels without training."""
    try:
        import torch
        from transformers import pipeline

        texts = kwargs.get("texts")
        if not texts:
            return {"status": "error", "error": "'texts' is required (list of strings or string)."}
        if isinstance(texts, str):
            texts = [texts]

        candidate_labels = kwargs.get("candidate_labels")
        if not candidate_labels or not isinstance(candidate_labels, list):
            return {"status": "error", "error": "'candidate_labels' must be a non-empty list of string labels."}

        model_name = kwargs.get("model", "typeform/distilbert-base-uncased-mnli")
        hypothesis_template = kwargs.get("hypothesis_template", "This text is about {}.")
        multi_label = kwargs.get("multi_label", False)

        t0 = time.time()
        device = 0 if torch.cuda.is_available() else -1

        classifier = pipeline("zero-shot-classification", model=model_name, device=device)
        res = classifier(
            texts,
            candidate_labels=candidate_labels,
            hypothesis_template=hypothesis_template,
            multi_label=multi_label,
        )
        if isinstance(res, dict):
            res = [res]

        predictions = []
        for r in res:
            predictions.append({
                "text": r["sequence"],
                "top_label": r["labels"][0],
                "top_score": round(r["scores"][0], 4),
                "scores": {label: round(score, 4) for label, score in zip(r["labels"], r["scores"])},
            })

        duration = round(time.time() - t0, 2)
        del classifier
        if device >= 0:
            torch.cuda.empty_cache()

        return {
            "status": "success",
            "predictions": predictions,
            "candidate_labels": candidate_labels,
            "model": model_name,
            "time_seconds": duration,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


ZERO_SHOT_SPEC = ToolSpec(
    name="tuiml_hf_zero_shot_classify",
    description="Classify text sequences into arbitrary candidate labels without any training using Hugging Face NLI zero-shot models.",
    input_schema={
        "type": "object",
        "properties": {
            "texts": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of texts (or single text string) to classify",
            },
            "candidate_labels": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of candidate category names to score",
            },
            "model": {
                "type": "string",
                "default": "typeform/distilbert-base-uncased-mnli",
                "description": "Zero-shot NLI model identifier",
            },
            "hypothesis_template": {
                "type": "string",
                "default": "This text is about {}.",
                "description": "Template used to format entailment hypothesis",
            },
            "multi_label": {
                "type": "boolean",
                "default": False,
                "description": "Whether classes can be independently true",
            },
        },
        "required": ["texts", "candidate_labels"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "predictions": {"type": "array", "items": {"type": "object"}},
            "candidate_labels": {"type": "array", "items": {"type": "string"}},
            "model": {"type": "string"},
            "time_seconds": {"type": "number"},
            "error": {"type": "string"},
        },
        "required": ["status"],
    },
    execute=execute_hf_zero_shot_classify,
    group="workflow",
    read_only=True,
    destructive=False,
    idempotent=True,
    open_world=False,
    reproducible=True,
)


# -----------------------------------------------------------------------------
# 8. Speech-to-Text Audio Transcription (Whisper)
# -----------------------------------------------------------------------------

def execute_hf_transcribe_audio(**kwargs) -> Dict[str, Any]:
    """Transcribe audio files to text using OpenAI Whisper via Hugging Face."""
    try:
        import torch
        from transformers import pipeline

        audio_path = kwargs.get("audio_path")
        if not audio_path or not os.path.exists(audio_path):
            return {"status": "error", "error": f"Audio file not found: {audio_path}"}

        model_name = kwargs.get("model", "openai/whisper-tiny")
        language = kwargs.get("language")

        t0 = time.time()
        device = 0 if torch.cuda.is_available() else -1

        asr_pipe = pipeline("automatic-speech-recognition", model=model_name, device=device)

        gen_kwargs = {}
        if language:
            gen_kwargs["language"] = language

        result = asr_pipe(audio_path, generate_kwargs=gen_kwargs)
        transcription = result.get("text", "")
        duration = round(time.time() - t0, 2)

        del asr_pipe
        if device >= 0:
            torch.cuda.empty_cache()

        return {
            "status": "success",
            "transcription": transcription,
            "audio_path": os.path.abspath(audio_path),
            "model": model_name,
            "time_seconds": duration,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


TRANSCRIBE_AUDIO_SPEC = ToolSpec(
    name="tuiml_hf_transcribe_audio",
    description="Transcribe speech audio files (.wav, .mp3, .ogg) to text using OpenAI Whisper via Hugging Face.",
    input_schema={
        "type": "object",
        "properties": {
            "audio_path": {"type": "string", "description": "Path to the audio file to transcribe"},
            "model": {
                "type": "string",
                "default": "openai/whisper-tiny",
                "description": "Pretrained Whisper model (e.g. 'openai/whisper-tiny', 'openai/whisper-base')",
            },
            "language": {"type": "string", "description": "Optional language code (e.g. 'en', 'es', 'fr')"},
        },
        "required": ["audio_path"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "transcription": {"type": "string"},
            "audio_path": {"type": "string"},
            "model": {"type": "string"},
            "time_seconds": {"type": "number"},
            "error": {"type": "string"},
        },
        "required": ["status"],
    },
    execute=execute_hf_transcribe_audio,
    group="workflow",
    read_only=True,
    destructive=False,
    idempotent=True,
    open_world=False,
    reproducible=True,
)


# -----------------------------------------------------------------------------
# 9. Cross-Modal Image-Text Matching & Zero-Shot Vision (CLIP)
# -----------------------------------------------------------------------------

def execute_hf_clip_match(**kwargs) -> Dict[str, Any]:
    """Score cross-modal alignment between an image and text queries using CLIP."""
    try:
        import torch
        from transformers import CLIPProcessor, CLIPModel

        image_path = kwargs.get("image_path")
        if not image_path or not os.path.exists(image_path):
            return {"status": "error", "error": f"Image file not found: {image_path}"}

        queries = kwargs.get("queries")
        if not queries or not isinstance(queries, list):
            return {"status": "error", "error": "'queries' must be a non-empty list of text strings."}

        model_name = kwargs.get("model", "openai/clip-vit-base-patch32")

        t0 = time.time()
        device = "cuda" if torch.cuda.is_available() else "cpu"

        processor = CLIPProcessor.from_pretrained(model_name)
        model = CLIPModel.from_pretrained(model_name).to(device)

        img = Image.open(image_path).convert("RGB")
        inputs = processor(text=queries, images=img, return_tensors="pt", padding=True).to(device)

        with torch.no_grad():
            outputs = model(**inputs)
            logits_per_image = outputs.logits_per_image  # (1, num_queries)
            probs = logits_per_image.softmax(dim=1)[0].cpu().numpy()
            scores = logits_per_image[0].cpu().numpy()

        matches = []
        for q, s, p in zip(queries, scores, probs):
            matches.append({
                "query": q,
                "score": round(float(s), 4),
                "probability": round(float(p), 4),
            })
        matches.sort(key=lambda m: m["probability"], reverse=True)

        duration = round(time.time() - t0, 2)
        del model
        del processor
        if device == "cuda":
            torch.cuda.empty_cache()

        return {
            "status": "success",
            "image_path": os.path.abspath(image_path),
            "top_match": matches[0]["query"],
            "top_probability": matches[0]["probability"],
            "matches": matches,
            "model": model_name,
            "time_seconds": duration,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


CLIP_MATCH_SPEC = ToolSpec(
    name="tuiml_hf_clip_match",
    description="Compute semantic similarity and zero-shot ranking between an image and multiple text queries using OpenAI CLIP.",
    input_schema={
        "type": "object",
        "properties": {
            "image_path": {"type": "string", "description": "Path to the image file to evaluate"},
            "queries": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of text queries or candidate class descriptions to match against",
            },
            "model": {
                "type": "string",
                "default": "openai/clip-vit-base-patch32",
                "description": "Pretrained CLIP model identifier",
            },
        },
        "required": ["image_path", "queries"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "image_path": {"type": "string"},
            "top_match": {"type": "string"},
            "top_probability": {"type": "number"},
            "matches": {"type": "array", "items": {"type": "object"}},
            "model": {"type": "string"},
            "time_seconds": {"type": "number"},
            "error": {"type": "string"},
        },
        "required": ["status"],
    },
    execute=execute_hf_clip_match,
    group="analysis",
    read_only=True,
    destructive=False,
    idempotent=True,
    open_world=False,
    reproducible=True,
)
