"""Neural network discovery, validation, hardware monitoring, async training, and explainability tools."""

import os
import traceback
import uuid
from typing import Any, Dict, List, Optional

import numpy as np

from ._spec import ToolSpec
from ._shared import _load_data, _load_model_from_disk, _save_model_to_disk
from ._state import _MODEL_INDEX


def execute_list_layers(**kwargs) -> Dict[str, Any]:
    """List available Keras layers and their default parameters."""
    try:
        import keras
        common_layers = ["Dense", "Conv2D", "MaxPooling2D", "Flatten", "Dropout", "LSTM", "BatchNormalization"]
        layers = {}
        for name in common_layers:
            if hasattr(keras.layers, name):
                cls = getattr(keras.layers, name)
                layers[name] = {"description": cls.__doc__.split('\n')[0] if cls.__doc__ else ""}
        
        return {
            "status": "success",
            "layers": layers,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


LIST_LAYERS_SPEC = ToolSpec(
    name="tuiml_neural_list_layers",
    description="List available Keras layers for use in SequentialClassifier/SequentialRegressor.",
    input_schema={
        "type": "object",
        "properties": {},
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "layers": {"type": "object"},
            "error": {"type": "string"}
        },
        "required": ["status"]
    },
    execute=execute_list_layers,
    group="discovery",
    read_only=True, destructive=False,
    idempotent=True, open_world=False,
    reproducible=False,
)


def execute_validate_sequence(**kwargs) -> Dict[str, Any]:
    """Validate a sequence of Keras layers for shape compatibility and estimate VRAM requirements."""
    try:
        import keras
        from tuiml.keras_torch.memory import estimate_model_vram, recommend_batch_size

        input_shape = kwargs.get("input_shape", (10,))
        layers_config = kwargs.get("layers", [])
        task_type = kwargs.get("task_type")
        num_classes = kwargs.get("num_classes")
        
        inputs = keras.Input(shape=input_shape)
        x = inputs
        warnings = []
        
        for idx, layer_def in enumerate(layers_config):
            cls_name = layer_def.get("class_name")
            config = layer_def.get("config", {})
            module_name = layer_def.get("module", "layers")

            if module_name == "layers":
                if not hasattr(keras.layers, cls_name):
                    return {"status": "error", "error": f"Unknown layer class at index {idx}: {cls_name}"}
                layer_cls = getattr(keras.layers, cls_name)
                layer = layer_cls(**config)
            elif module_name == "applications":
                if not hasattr(keras.applications, cls_name):
                    return {"status": "error", "error": f"Unknown application at index {idx}: {cls_name}"}
                layer_cls = getattr(keras.applications, cls_name)
                layer = layer_cls(**config)
            elif module_name in ("huggingface", "hf"):
                from tuiml.keras_torch.huggingface import build_hf_layer
                try:
                    layer = build_hf_layer(cls_name, config)
                except Exception as e:
                    return {"status": "error", "error": f"Failed to build Hugging Face layer at index {idx}: {str(e)}"}
            else:
                return {"status": "error", "error": f"Unknown module at index {idx}: {module_name}"}

            try:
                x = layer(x)
            except Exception as e:
                return {
                    "status": "error", 
                    "error": f"Validation failed at layer {idx} ({cls_name}): {str(e)}",
                    "traceback": traceback.format_exc()
                }
                
        if len(x.shape) > 2:
            warnings.append(
                f"Output shape before predictor head is {tuple(x.shape)}, which is >2D. "
                "You may have forgotten a Flatten or GlobalAveragePooling layer."
            )
            
        head = None
        if task_type == "classification" and num_classes is not None:
            if num_classes == 2:
                head = keras.layers.Dense(1, activation="sigmoid", name="auto_head")
            else:
                head = keras.layers.Dense(num_classes, activation="softmax", name="auto_head")
        elif task_type == "multilabel_classification" and num_classes is not None:
            head = keras.layers.Dense(num_classes, activation="sigmoid", name="auto_head")
        elif task_type == "regression":
            head = keras.layers.Dense(1, activation="linear", name="auto_head")
        elif task_type == "multitarget_regression" and num_classes is not None:
            head = keras.layers.Dense(num_classes, activation="linear", name="auto_head")
            
        if head is not None:
            try:
                x = head(x)
            except Exception as e:
                return {
                    "status": "error", 
                    "error": f"Validation failed when applying auto-added {task_type} head: {str(e)}",
                    "traceback": traceback.format_exc()
                }

        out_shape = [dim if dim is not None else -1 for dim in x.shape]
        
        # Estimate VRAM usage and recommend batch size
        vram_rec = recommend_batch_size(input_shape=tuple(input_shape), layers=layers_config)
        vram_est = estimate_model_vram(
            input_shape=tuple(input_shape),
            batch_size=vram_rec.get("recommended_batch_size", 32),
            layers=layers_config
        )

        return {
            "status": "success",
            "valid": True,
            "output_shape": tuple(out_shape),
            "warnings": warnings,
            "recommended_batch_size": vram_rec.get("recommended_batch_size", 32),
            "estimated_vram_mb": vram_est.get("total_estimated_mb"),
            "free_vram_mb": vram_rec.get("free_vram_mb"),
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


VALIDATE_SEQUENCE_SPEC = ToolSpec(
    name="tuiml_neural_validate_sequence",
    description="Dry-run a layer sequence to validate shape compatibility and estimate memory/batch sizes.",
    input_schema={
        "type": "object",
        "properties": {
            "input_shape": {
                "type": "array",
                "items": {"type": "integer"},
                "description": "The input shape tuple, excluding batch size (e.g., [28, 28, 1] or [32, 32, 3])"
            },
            "layers": {
                "type": "array",
                "description": "List of layer config dictionaries (class_name, config)",
            },
            "task_type": {
                "type": "string",
                "enum": ["classification", "regression", "multilabel_classification", "multitarget_regression", "custom"],
                "description": "Optional task type to simulate the auto-added predictor head."
            },
            "num_classes": {
                "type": "integer",
                "description": "Number of classes or targets."
            }
        },
        "required": ["input_shape", "layers"]
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "valid": {"type": "boolean"},
            "output_shape": {"type": "array", "items": {"type": "integer"}},
            "recommended_batch_size": {"type": "integer"},
            "estimated_vram_mb": {"type": "number"},
            "free_vram_mb": {"type": "number"},
            "warnings": {"type": "array", "items": {"type": "string"}},
            "error": {"type": "string"}
        },
        "required": ["status"]
    },
    execute=execute_validate_sequence,
    group="discovery",
    read_only=True, destructive=False,
    idempotent=True, open_world=False,
    reproducible=False,
)


def execute_list_models(**kwargs) -> Dict[str, Any]:
    """List pre-trained models in keras.applications."""
    try:
        import keras.applications
        models = [m for m in dir(keras.applications) if not m.startswith("_") and m[0].isupper()]
        return {
            "status": "success",
            "models": models
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


LIST_MODELS_SPEC = ToolSpec(
    name="tuiml_neural_list_models",
    description="List available pre-trained models in keras.applications.",
    input_schema={
        "type": "object",
        "properties": {},
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "models": {"type": "array", "items": {"type": "string"}},
            "error": {"type": "string"}
        },
        "required": ["status"]
    },
    execute=execute_list_models,
    group="discovery",
    read_only=True, destructive=False,
    idempotent=True, open_world=False,
    reproducible=False,
)


def execute_list_hf_models(**kwargs) -> Dict[str, Any]:
    """List recommended Hugging Face models for transformer backbones and text embeddings."""
    try:
        from tuiml.keras_torch.huggingface import list_popular_hf_models
        task = kwargs.get("task")
        modality = kwargs.get("modality")
        models = list_popular_hf_models(task=task, modality=modality)
        return {
            "status": "success",
            "models": models,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


LIST_HF_MODELS_SPEC = ToolSpec(
    name="tuiml_neural_list_hf_models",
    description="List popular and tested Hugging Face models for transformer backbones and text embeddings.",
    input_schema={
        "type": "object",
        "properties": {
            "task": {
                "type": "string",
                "description": "Optional filter by task (e.g. sentence-embeddings, masked-lm, image-classification)"
            },
            "modality": {
                "type": "string",
                "enum": ["text", "vision"],
                "description": "Optional filter by modality (text or vision)"
            }
        },
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "models": {
                "type": "array",
                "items": {"type": "object"}
            },
            "error": {"type": "string"}
        },
        "required": ["status"]
    },
    execute=execute_list_hf_models,
    group="discovery",
    read_only=True, destructive=False,
    idempotent=True, open_world=False,
    reproducible=False,
)


def execute_hardware_status(**kwargs) -> Dict[str, Any]:
    """Query current GPU hardware status, free VRAM, and get safe batch size recommendations."""
    try:
        from tuiml.keras_torch.memory import get_gpu_memory_info, recommend_batch_size

        input_shape = kwargs.get("input_shape")
        layers = kwargs.get("layers")
        safety_margin = kwargs.get("safety_margin", 0.35)

        mem = get_gpu_memory_info()
        rec = None
        if input_shape:
            rec = recommend_batch_size(
                input_shape=tuple(input_shape),
                layers=layers,
                safety_margin=safety_margin,
            )

        return {
            "status": "success",
            "available": mem.get("available", False),
            "device_name": mem.get("device_name"),
            "total_vram_mb": mem.get("total_mb", 0.0),
            "free_vram_mb": mem.get("free_mb", 0.0),
            "allocated_vram_mb": mem.get("allocated_mb", 0.0),
            "reserved_vram_mb": mem.get("reserved_mb", 0.0),
            "message": mem.get("message", ""),
            "recommendation": rec,
        }
    except Exception as e:
        return {"status": "error", "error": str(e), "traceback": traceback.format_exc()}


HARDWARE_STATUS_SPEC = ToolSpec(
    name="tuiml_neural_hardware_status",
    description="Poll GPU VRAM availability and get batch size recommendations before designing or training a model.",
    input_schema={
        "type": "object",
        "properties": {
            "input_shape": {
                "type": "array",
                "items": {"type": "integer"},
                "description": "Optional sample input shape, e.g. [32, 32, 3], to compute recommended batch size."
            },
            "layers": {
                "type": "array",
                "description": "Optional layer configuration list to estimate model capacity."
            },
            "safety_margin": {
                "type": "number",
                "default": 0.35,
                "description": "Fraction of free VRAM to keep untouched as safety headroom."
            }
        },
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "available": {"type": "boolean"},
            "device_name": {"type": "string"},
            "total_vram_mb": {"type": "number"},
            "free_vram_mb": {"type": "number"},
            "allocated_vram_mb": {"type": "number"},
            "message": {"type": "string"},
            "recommendation": {"type": "object"},
            "error": {"type": "string"}
        },
        "required": ["status"]
    },
    execute=execute_hardware_status,
    group="discovery",
    read_only=True, destructive=False,
    idempotent=True, open_world=False,
    reproducible=False,
)


def execute_train_async(**kwargs) -> Dict[str, Any]:
    """Launch neural network training asynchronously in a background thread."""
    try:
        from tuiml.keras_torch.neural import SequentialClassifier, SequentialRegressor
        from tuiml.keras_torch.async_training import start_async_training

        algorithm = kwargs.get("algorithm", "SequentialClassifier")
        layers = kwargs.get("layers", [])
        data_source = kwargs.get("data")
        epochs = kwargs.get("epochs", 10)
        batch_size = kwargs.get("batch_size", 32)
        auto_batch_size = kwargs.get("auto_batch_size", True)
        validation_split = kwargs.get("validation_split", 0.1)
        optimizer = kwargs.get("optimizer", "adam")
        job_id = kwargs.get("job_id") or f"job_{uuid.uuid4().hex[:8]}"
        status_file = kwargs.get("status_file")

        if not data_source:
            return {"status": "error", "error": "Missing required parameter 'data'"}

        ds = _load_data(data_source)
        X, y = ds.X, ds.y

        if algorithm == "SequentialClassifier":
            model = SequentialClassifier(
                layers=layers,
                epochs=epochs,
                batch_size=batch_size,
                auto_batch_size=auto_batch_size,
                validation_split=validation_split,
                optimizer=optimizer,
                verbose=1,
            )
        elif algorithm == "SequentialRegressor":
            model = SequentialRegressor(
                layers=layers,
                epochs=epochs,
                batch_size=batch_size,
                auto_batch_size=auto_batch_size,
                validation_split=validation_split,
                optimizer=optimizer,
                verbose=1,
            )
        else:
            return {"status": "error", "error": f"Unsupported algorithm '{algorithm}' for async neural training."}

        job = start_async_training(
            model=model,
            X=X,
            y=y,
            job_id=job_id,
            status_file=status_file,
            epochs=epochs,
            batch_size=batch_size,
            validation_split=validation_split,
        )

        return {
            "status": "success",
            "job_id": job_id,
            "training_status": "running",
            "epochs": epochs,
            "batch_size": batch_size,
            "message": f"Async training job '{job_id}' started in background. Use 'tuiml_neural_job_status' to monitor progress."
        }
    except Exception as e:
        return {"status": "error", "error": str(e), "traceback": traceback.format_exc()}


TRAIN_ASYNC_SPEC = ToolSpec(
    name="tuiml_neural_train_async",
    description="Launch neural network training asynchronously in the background so it does not block the agent.",
    input_schema={
        "type": "object",
        "properties": {
            "algorithm": {
                "type": "string",
                "enum": ["SequentialClassifier", "SequentialRegressor"],
                "default": "SequentialClassifier"
            },
            "layers": {
                "type": "array",
                "description": "List of Keras layer specifications."
            },
            "data": {
                "type": "string",
                "description": "Dataset name, file path, or uploaded dataset ID."
            },
            "epochs": {"type": "integer", "default": 10},
            "batch_size": {"type": "integer", "default": 32},
            "auto_batch_size": {"type": "boolean", "default": True},
            "validation_split": {"type": "number", "default": 0.1},
            "optimizer": {"type": "string", "default": "adam"},
            "job_id": {"type": "string", "description": "Optional custom job ID"},
            "status_file": {"type": "string", "description": "Optional file path to write progress JSON"}
        },
        "required": ["layers", "data"]
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "job_id": {"type": "string"},
            "training_status": {"type": "string"},
            "message": {"type": "string"},
            "error": {"type": "string"}
        },
        "required": ["status"]
    },
    execute=execute_train_async,
    group="workflow",
    read_only=False, destructive=False,
    idempotent=False, open_world=False,
    reproducible=False,
)


def execute_job_status(**kwargs) -> Dict[str, Any]:
    """Check progress, speed, ETA, and status of an asynchronous neural training job."""
    try:
        from tuiml.keras_torch.async_training import get_training_job

        job_id = kwargs.get("job_id")
        wait_completion = kwargs.get("wait_completion", False)
        timeout = kwargs.get("timeout")
        save_model = kwargs.get("save_model", False)

        if not job_id:
            return {"status": "error", "error": "Missing required parameter 'job_id'"}

        job = get_training_job(job_id)
        if not job:
            return {"status": "error", "error": f"No training job found with ID '{job_id}'"}

        if wait_completion and not job.is_done():
            job.wait(timeout=timeout)

        poll_res = job.poll()
        result = {
            "status": "success",
            "job_id": job_id,
            "job_status": poll_res["status"],
            "is_running": poll_res["is_running"],
            "progress": poll_res["progress"],
            "error": poll_res["error"],
        }

        # If completed and save requested
        if job.status == "completed" and save_model:
            model_id = f"model_{job_id}"
            save_path = _save_model_to_disk(job.model, model_id)
            _MODEL_INDEX[model_id] = save_path
            result["model_id"] = model_id
            result["model_path"] = save_path

        return result
    except Exception as e:
        return {"status": "error", "error": str(e), "traceback": traceback.format_exc()}


JOB_STATUS_SPEC = ToolSpec(
    name="tuiml_neural_job_status",
    description="Check real-time progress, samples/sec, ETA, and metrics of a background neural training job.",
    input_schema={
        "type": "object",
        "properties": {
            "job_id": {"type": "string", "description": "The ID of the training job to inspect"},
            "wait_completion": {"type": "boolean", "default": False, "description": "Whether to wait for job completion"},
            "timeout": {"type": "number", "description": "Max seconds to wait if wait_completion is true"},
            "save_model": {"type": "boolean", "default": False, "description": "Save and index the model upon completion"}
        },
        "required": ["job_id"]
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "job_id": {"type": "string"},
            "job_status": {"type": "string"},
            "is_running": {"type": "boolean"},
            "progress": {"type": "object"},
            "model_id": {"type": "string"},
            "model_path": {"type": "string"},
            "error": {"type": "string"}
        },
        "required": ["status"]
    },
    execute=execute_job_status,
    group="workflow",
    read_only=True, destructive=False,
    idempotent=True, open_world=False,
    reproducible=False,
)


def execute_explain(**kwargs) -> Dict[str, Any]:
    """Generate Grad-CAM or activation visual explainability plots for a trained model."""
    try:
        from tuiml.keras_torch.explainability import generate_gradcam, visualize_activations

        model_id = kwargs.get("model_id")
        model_path = kwargs.get("model_path")
        method = kwargs.get("method", "gradcam")
        data_source = kwargs.get("data")
        sample_index = kwargs.get("sample_index", 0)
        layer_name = kwargs.get("layer_name")
        target_class = kwargs.get("target_class")
        save_path = kwargs.get("save_path") or f"explain_{uuid.uuid4().hex[:8]}.png"

        model = _load_model_from_disk(model_id=model_id, model_path=model_path)
        if model is None:
            return {"status": "error", "error": f"Model not found for model_id='{model_id}' or model_path='{model_path}'"}

        image_path = kwargs.get("image_path")

        # Fetch image
        if image_path and os.path.exists(image_path):
            if image_path.endswith(".npy"):
                sample_img = np.load(image_path)
            else:
                import matplotlib.image as mpimg
                sample_img = mpimg.imread(image_path)
        elif data_source:
            if isinstance(data_source, str) and (data_source.endswith(".npy") or data_source.endswith(".npz")):
                arr = np.load(data_source)
                X = arr["X"] if "X" in arr else (arr["arr_0"] if "arr_0" in arr else arr)
            else:
                ds = _load_data(data_source)
                X = ds.X
            if sample_index >= len(X):
                return {"status": "error", "error": f"sample_index {sample_index} exceeds dataset size {len(X)}"}
            sample_img = X[sample_index]
        else:
            return {"status": "error", "error": "Must provide 'data' source or 'image_path' to retrieve the sample image to explain."}

        if method == "gradcam":
            cam_res = generate_gradcam(
                model=model,
                image=sample_img,
                target_class=target_class,
                layer_name=layer_name,
                save_path=save_path,
            )
            return {
                "status": "success",
                "method": "gradcam",
                "figure_path": cam_res["figure_path"],
                "predicted_class": cam_res["predicted_class"],
                "target_class": cam_res["target_class"],
                "class_probability": cam_res["class_probability"],
                "layer_name": cam_res["layer_name"],
                "message": f"Grad-CAM explanation saved to '{cam_res['figure_path']}' for class {cam_res['target_class']}."
            }
        elif method == "activations":
            act_res = visualize_activations(
                model=model,
                image=sample_img,
                layer_name=layer_name,
                save_path=save_path,
            )
            return {
                "status": "success",
                "method": "activations",
                "figure_path": act_res["figure_path"],
                "layer_name": act_res["layer_name"],
                "n_channels": act_res["n_channels"],
                "message": f"Activations grid saved to '{act_res['figure_path']}'."
            }
        else:
            return {"status": "error", "error": f"Unknown method '{method}'. Choose 'gradcam' or 'activations'."}
    except Exception as e:
        return {"status": "error", "error": str(e), "traceback": traceback.format_exc()}


EXPLAIN_SPEC = ToolSpec(
    name="tuiml_neural_explain",
    description="Generate explainability visualizations (Grad-CAM class activation map or feature map activations) for a trained neural model.",
    input_schema={
        "type": "object",
        "properties": {
            "model_id": {"type": "string", "description": "Trained model ID"},
            "model_path": {"type": "string", "description": "Path to serialized model"},
            "data": {"type": "string", "description": "Dataset name or path containing the sample to explain"},
            "image_path": {"type": "string", "description": "Direct path to an image file or .npy file to explain"},
            "sample_index": {"type": "integer", "default": 0, "description": "Sample index in the dataset"},
            "method": {
                "type": "string",
                "enum": ["gradcam", "activations"],
                "default": "gradcam",
                "description": "Explainability method to use"
            },
            "layer_name": {"type": "string", "description": "Optional convolutional layer name to explain"},
            "target_class": {"type": "integer", "description": "Optional target class index (defaults to top predicted)"},
            "save_path": {"type": "string", "description": "Destination file path for the output PNG figure"}
        },
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "method": {"type": "string"},
            "figure_path": {"type": "string"},
            "predicted_class": {"type": "integer"},
            "target_class": {"type": "integer"},
            "class_probability": {"type": "number"},
            "layer_name": {"type": "string"},
            "message": {"type": "string"},
            "error": {"type": "string"}
        },
        "required": ["status"]
    },
    execute=execute_explain,
    group="analysis",
    read_only=True, destructive=False,
    idempotent=True, open_world=False,
    reproducible=False,
)
