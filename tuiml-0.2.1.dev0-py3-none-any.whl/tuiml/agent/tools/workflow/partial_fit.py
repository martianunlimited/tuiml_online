"""Incremental single-step/batch model training via partial_fit."""

from typing import Any, Dict, List, Optional
from .._spec import ToolSpec
from .train import execute_train


def execute_partial_fit(**kwargs) -> Dict[str, Any]:
    """Execute single-step/batch incremental training via the partial_fit method.

    Backs the ``tuiml_partial_fit`` tool. Trains or updates an existing model
    with a single batch of training instances using the canonical ``partial_fit``
    method. Consistent with the naming convention across all TuiML and
    scikit-learn incremental estimators (SGD, MLP, Naive Bayes, KNN, Keras-Torch,
    and CapyMOA).

    Parameters
    ----------
    model_id : str, optional
        ID of an existing model previously created or trained.
    model_path : str, optional
        Explicit path to a serialized model.
    data : str
        Dataset or batch to train on: dataset_id, file path, or built-in name.
    classes : list, optional
        List of all possible class labels (classification only). Recommended on the
        first partial_fit call if the initial batch might not contain all classes.
    algorithm : str, optional
        Algorithm name if initializing a new model on the first batch.
    algorithm_params : dict, optional
        Constructor parameters if initializing a new model.
    save_path : str, optional
        Destination path to save the updated model.

    Returns
    -------
    result : dict
        On success: ``status`` ('success'), ``model_id``, ``model_path``,
        ``model_class``, and iteration/batch metadata.
    """
    classes = kwargs.pop("classes", None)
    stage_kwargs = kwargs.pop("stage_kwargs", {}) or {}
    if classes is not None:
        stage_kwargs["classes"] = classes

    kwargs["stage"] = "partial_fit"
    kwargs["stage_kwargs"] = stage_kwargs
    return execute_train(**kwargs)


SPEC = ToolSpec(
    name="tuiml_partial_fit",
    description=(
        "Incrementally train a classifier or regressor on a single batch of data "
        "using its canonical partial_fit method. Updates the model weights without "
        "re-initializing previously learned parameters."
    ),
    input_schema={
        "type": "object",
        "properties": {
            "model_id": {
                "type": "string",
                "description": "ID of the existing model to update with partial_fit."
            },
            "model_path": {
                "type": "string",
                "description": "Path to a serialized model file."
            },
            "data": {
                "type": "string",
                "description": "Batch dataset: path to CSV/npy file, dataset ID, or built-in dataset name."
            },
            "classes": {
                "type": "array",
                "items": {"type": ["string", "integer", "number"]},
                "description": "All expected class labels. Crucial on the first partial_fit call if the batch lacks some classes."
            },
            "algorithm": {
                "type": "string",
                "description": "Algorithm name (e.g. 'SGDClassifier', 'SequentialClassifier') if initializing on this batch."
            },
            "algorithm_params": {
                "type": "object",
                "description": "Parameters to instantiate the algorithm if initializing on this batch."
            },
            "save_path": {
                "type": "string",
                "description": "Optional destination path to save the updated model."
            }
        },
        "required": ["data"]
    },
    output_schema={
        "type": "object",
        "properties": {
            "status": {"type": "string", "enum": ["success", "error"]},
            "model_id": {"type": "string"},
            "model_path": {"type": "string"},
            "model_class": {"type": "string"},
            "error": {"type": "string"},
            "error_type": {"type": "string"}
        },
        "required": ["status"]
    },
    execute=execute_partial_fit,
    group="workflow",
    read_only=False,
    destructive=False,
    idempotent=False,
    open_world=False,
    reproducible=True,
    seeded=True,
)
