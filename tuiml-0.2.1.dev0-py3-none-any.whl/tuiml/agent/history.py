import json
import os
import uuid
from pathlib import Path
from typing import List, Dict, Any, Optional

# Default trace path matching server.py
_DEFAULT_TRACE_PATH = Path(os.environ.get(
    "TUIML_MCP_TRACE_FILE",
    str(Path.home() / ".tuiml" / "logs" / "mcp.jsonl"),
))

def get_session_trace(limit: Optional[int] = None, trace_path: Path = _DEFAULT_TRACE_PATH) -> List[Dict[str, Any]]:
    """Retrieve the MCP call trace history."""
    if not trace_path.exists():
        return []
    
    traces = []
    try:
        with trace_path.open("r") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    traces.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
    except Exception:
        pass
    
    if limit is not None and limit > 0:
        # Return the last N traces
        return traces[-limit:]
    return traces

def _format_python_args(args: Dict[str, Any]) -> str:
    """Format dictionary arguments into a multi-line python kwargs string."""
    if not args:
        return ""
    
    lines = []
    for k, v in args.items():
        if isinstance(v, str):
            # Try to handle multi-line strings nicely, otherwise just repr
            val_str = repr(v)
        else:
            val_str = json.dumps(v, indent=4)
            # Fix true/false/null to True/False/None
            val_str = val_str.replace("true", "True").replace("false", "False").replace("null", "None")
        
        # indent inner lines of JSON if necessary
        val_str = val_str.replace("\n", "\n    ")
        lines.append(f"    {k}={val_str},")
    return "\n".join(lines)

def generate_python_script(trace: List[Dict[str, Any]]) -> str:
    """Generate a Python script from a list of trace events."""
    script_lines = [
        "#!/usr/bin/env python",
        "# Generated TuiML Session History",
        "import tuiml.api as api",
        "import pandas as pd",
        "import numpy as np",
        ""
    ]
    
    call_counter = 1
    for event in trace:
        phase = event.get("phase")
        if phase == "annotation":
            # Add as comments
            notes = event.get("text", "").split("\n")
            for note in notes:
                script_lines.append(f"# {note}")
            script_lines.append("")
        elif phase == "call":
            tool = event.get("tool", "")
            if not tool.startswith("tuiml_"):
                continue
                
            api_method = tool.replace("tuiml_", "")
            args = event.get("args", {})
            
            script_lines.append(f"# MCP Tool Call: {tool}")
            if args:
                args_str = _format_python_args(args)
                script_lines.append(f"result_{call_counter} = api.{api_method}(")
                script_lines.append(args_str)
                script_lines.append(")")
            else:
                script_lines.append(f"result_{call_counter} = api.{api_method}()")
            script_lines.append("")
            call_counter += 1
            
    return "\n".join(script_lines)

def export_jupyter_notebook(trace: List[Dict[str, Any]], output_path: str) -> str:
    """Generate and save a Jupyter notebook from trace events."""
    cells = []
    
    # Init cell
    cells.append({
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "# Generated TuiML Session Notebook\n",
            "import tuiml.api as api\n",
            "import pandas as pd\n",
            "import numpy as np"
        ]
    })
    
    call_counter = 1
    for event in trace:
        phase = event.get("phase")
        
        if phase == "annotation":
            cells.append({
                "cell_type": "markdown",
                "metadata": {},
                "source": [line + "\n" for line in event.get("text", "").split("\n")]
            })
            
        elif phase == "call":
            tool = event.get("tool", "")
            if not tool.startswith("tuiml_"):
                continue
                
            api_method = tool.replace("tuiml_", "")
            args = event.get("args", {})
            
            source = []
            source.append(f"# MCP Tool Call: {tool}\n")
            if args:
                args_str = _format_python_args(args)
                source.append(f"result_{call_counter} = api.{api_method}(\n")
                source.append(args_str + "\n")
                source.append(")")
            else:
                source.append(f"result_{call_counter} = api.{api_method}()")
                
            cells.append({
                "cell_type": "code",
                "execution_count": None,
                "metadata": {},
                "outputs": [],
                "source": source
            })
            call_counter += 1
            
    notebook = {
        "cells": cells,
        "metadata": {},
        "nbformat": 4,
        "nbformat_minor": 5
    }
    
    # Save to file
    out_path = Path(output_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w") as f:
        f.write(json.dumps(notebook, indent=2))
        
    return str(out_path.absolute())
