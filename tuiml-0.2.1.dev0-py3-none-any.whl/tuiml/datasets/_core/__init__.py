"""
Internal utilities for datasets module.
"""

from tuiml.datasets._core.arff_parser import ARFFData, parse_arff
ArffParser = ARFFData

__all__ = ["ArffParser", "ARFFData", "parse_arff"]
