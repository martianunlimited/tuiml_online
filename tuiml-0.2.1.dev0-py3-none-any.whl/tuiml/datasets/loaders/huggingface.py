"""Hugging Face Hub dataset loader for TuiML."""

from typing import Optional, Union, List
from pathlib import Path

from tuiml.datasets.loaders.arff import Dataset
from tuiml.datasets.loaders.pandas import from_pandas

_EXTRA = "huggingface"


def load_hf_dataset(
    path: str,
    name: Optional[str] = None,
    split: str = "train",
    target_column: Optional[Union[str, int]] = -1,
    max_samples: Optional[int] = None,
    columns: Optional[List[str]] = None,
) -> Dataset:
    """Load a dataset from the Hugging Face Hub into a standard TuiML Dataset.

    Downloads or streams tabular, text, or multimodal datasets hosted on
    Hugging Face Hub (e.g. ``"imdb"``, ``"ag_news"``, ``"glue"``, etc.) and
    converts them into a TuiML ``Dataset`` compatible with all preprocessing,
    workflows, and classifiers.

    Parameters
    ----------
    path : str
        Dataset identifier on Hugging Face Hub (e.g. ``"imdb"`` or ``"rotten_tomatoes"``).
    name : str, optional
        Subset configuration name (e.g. ``"mrpc"`` for GLUE).
    split : str, default="train"
        Which split to load (e.g. ``"train"``, ``"test"``, ``"validation"``, or ``"train[:500]"``).
    target_column : str, int, or None, default=-1
        Target variable column name or integer index. Set to ``None`` for unsupervised data.
    max_samples : int, optional
        Maximum number of samples to load (subsamples the split if specified).
    columns : list of str, optional
        Subset of columns to keep.

    Returns
    -------
    dataset : Dataset
        Standard TuiML Dataset instance containing ``X``, ``y``, and metadata.

    Examples
    --------
    >>> from tuiml.datasets import load_hf_dataset
    >>> data = load_hf_dataset("rotten_tomatoes", split="test", max_samples=100)
    >>> data.n_samples, len(data.feature_names)
    (100, 1)
    """
    try:
        import datasets
    except ImportError as exc:
        raise ImportError(
            f"Loading Hugging Face Hub datasets requires the 'datasets' package. "
            f"Install it with: pip install 'tuiml[{_EXTRA}]' or pip install datasets"
        ) from exc

    # Handle legacy top-level dataset IDs that now require namespace/name on Hugging Face Hub
    canonical_map = {
        "rotten_tomatoes": "cornell-movie-review-data/rotten_tomatoes",
        "ag_news": "fancyzhx/ag_news",
        "imdb": "stanfordnlp/imdb",
    }
    hub_path = canonical_map.get(path, path)

    # Load dataset from hub
    kwargs = {}
    if name is not None:
        kwargs["name"] = name

    try:
        hf_ds = datasets.load_dataset(hub_path, split=split, **kwargs)
    except Exception as err:
        if hub_path != path and path in canonical_map:
            raise
        if path in canonical_map:
            hf_ds = datasets.load_dataset(canonical_map[path], split=split, **kwargs)
        else:
            raise err

    if max_samples is not None and len(hf_ds) > max_samples:
        hf_ds = hf_ds.select(range(max_samples))

    df = hf_ds.to_pandas()

    if columns is not None:
        valid_cols = [c for c in columns if c in df.columns]
        if target_column in df.columns and target_column not in valid_cols:
            valid_cols.append(target_column)
        df = df[valid_cols]

    tuiml_dataset = from_pandas(df, target_column=target_column)
    tuiml_dataset.name = f"hf:{path}"
    tuiml_dataset.description = f"Hugging Face dataset '{path}' (split: {split})"

    return tuiml_dataset
