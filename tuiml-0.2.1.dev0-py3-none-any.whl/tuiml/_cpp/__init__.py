"""C++ acceleration backend for TuiML.

This package provides optimized C++ implementations of computational hot
paths. When running in environments without compiled extensions (such as
pure-Python mode or Pyodide WASM without C++ extensions), graceful
Python/NumPy fallbacks are used.
"""

try:
    from tuiml._cpp_ext import tree, distance, neighbors, svm
    HAS_CPP_EXT = True
except (ImportError, ModuleNotFoundError):
    tree = distance = neighbors = svm = None
    HAS_CPP_EXT = False

__all__ = ["tree", "distance", "neighbors", "svm", "HAS_CPP_EXT"]

