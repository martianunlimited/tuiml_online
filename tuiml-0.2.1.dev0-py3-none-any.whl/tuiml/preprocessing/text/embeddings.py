"""Hugging Face text embedding transformer for TuiML preprocessing pipelines."""

from typing import Any, Dict, List, Optional, Union
import numpy as np

from tuiml.base.preprocessing import Transformer, transformer

_EXTRA = "huggingface"


def _ensure_transformers():
    """Ensure transformers and torch are installed."""
    try:
        import torch  # noqa: F401
        import transformers  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            f"HFTextEmbedder requires 'transformers' and 'torch'. "
            f"Install them with: pip install 'tuiml[{_EXTRA}]'"
        ) from exc


@transformer(tags=["text", "embedding", "nlp", "huggingface", "transformers"], version="1.0.0")
class HFTextEmbedder(Transformer):
    """Transform text documents into dense semantic embeddings using Hugging Face models.

    Converts raw text columns or collections of documents into fixed-size dense
    vectors using pretrained transformer representations (e.g., Sentence-Transformers,
    BERT, DistilBERT). The resulting feature matrix can be directly consumed by
    any downstream TuiML classifier, regressor, or clustering algorithm in a Workflow.

    Parameters
    ----------
    model_name : str, default="sentence-transformers/all-MiniLM-L6-v2"
        Hugging Face Hub repository ID or path to a local directory with weights.
    batch_size : int, default=32
        Batch size used for tokenization and model inference.
    max_length : int, default=128
        Maximum sequence length for tokenization truncation.
    pooling : str, default="mean"
        Strategy to aggregate token representations into a single sentence vector:
        ``"mean"`` (attention-weighted average), ``"cls"`` (first token), or ``"max"``.
    normalize : bool, default=True
        Whether to L2-normalize embeddings to unit length (ideal for cosine similarity
        and linear / distance-based classifiers).
    device : str, default="auto"
        Compute device: ``"auto"`` (uses CUDA if available), ``"cuda"``, or ``"cpu"``.

    Attributes
    ----------
    n_features_out_ : int
        Dimensionality of the extracted embedding vectors (e.g. 384 for MiniLM, 768 for BERT).
    model_ : AutoModel
        Loaded Hugging Face PyTorch model.
    tokenizer_ : AutoTokenizer
        Loaded Hugging Face tokenizer.
    """

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Dict[str, Any]]:
        return {
            "model_name": {
                "type": "string",
                "default": "sentence-transformers/all-MiniLM-L6-v2",
                "description": "Pretrained Hugging Face model repository or local path",
            },
            "batch_size": {
                "type": "integer",
                "default": 32,
                "description": "Inference batch size",
            },
            "max_length": {
                "type": "integer",
                "default": 128,
                "description": "Maximum token sequence length",
            },
            "pooling": {
                "type": "string",
                "enum": ["mean", "cls", "max"],
                "default": "mean",
                "description": "Token pooling strategy",
            },
            "normalize": {
                "type": "boolean",
                "default": True,
                "description": "Whether to L2-normalize output embeddings",
            },
            "device": {
                "type": "string",
                "enum": ["auto", "cuda", "cpu"],
                "default": "auto",
                "description": "Compute device",
            },
        }

    def __init__(
        self,
        model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
        batch_size: int = 32,
        max_length: int = 128,
        pooling: str = "mean",
        normalize: bool = True,
        device: str = "auto",
    ):
        super().__init__()
        self.model_name = model_name
        self.batch_size = batch_size
        self.max_length = max_length
        self.pooling = pooling
        self.normalize = normalize
        self.device = device

    def _extract_text_list(self, X: Any) -> List[str]:
        """Convert input data into a list of strings."""
        if hasattr(X, "to_numpy"):
            X = X.to_numpy()
        elif hasattr(X, "tolist"):
            X = X.tolist()

        if isinstance(X, list):
            if len(X) > 0 and isinstance(X[0], (list, tuple)):
                # Flatten single-column tabular text or join multi-column text
                return [" ".join(str(item) for item in row) for row in X]
            return [str(doc) for doc in X]

        arr = np.asarray(X)
        if arr.ndim == 2:
            if arr.shape[1] == 1:
                return [str(x) for x in arr.flatten()]
            # Multi-column text
            return [" ".join(str(cell) for cell in row) for row in arr]
        return [str(x) for x in arr.flatten()]

    def _get_device(self):
        import torch
        if self.device == "cuda":
            return torch.device("cuda" if torch.cuda.is_available() else "cpu")
        if self.device == "cpu":
            return torch.device("cpu")
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def fit(self, X: Any, y: Optional[Any] = None) -> "HFTextEmbedder":
        """Load the model and tokenizer, and determine output dimension."""
        _ensure_transformers()
        import torch
        from transformers import AutoModel, AutoTokenizer

        self.tokenizer_ = AutoTokenizer.from_pretrained(self.model_name)
        self.model_ = AutoModel.from_pretrained(self.model_name)
        self.model_.eval()

        device = self._get_device()
        self.model_.to(device)

        config = self.model_.config
        self.n_features_out_ = getattr(
            config,
            "hidden_size",
            getattr(config, "d_model", getattr(config, "dim", 384)),
        )

        self._is_fitted = True
        return self

    def transform(self, X: Any) -> np.ndarray:
        """Transform texts into dense embedding representations."""
        self._check_is_fitted()
        import torch

        documents = self._extract_text_list(X)
        if len(documents) == 0:
            return np.empty((0, self.n_features_out_), dtype=np.float32)

        device = self._get_device()
        all_embeddings: List[np.ndarray] = []
        batch_size = max(1, self.batch_size)

        with torch.no_grad():
            for i in range(0, len(documents), batch_size):
                batch_docs = documents[i : i + batch_size]
                encoded = self.tokenizer_(
                    batch_docs,
                    padding=True,
                    truncation=True,
                    max_length=self.max_length,
                    return_tensors="pt",
                )
                encoded = {k: v.to(device) for k, v in encoded.items()}

                outputs = self.model_(**encoded)
                hidden_states = getattr(outputs, "last_hidden_state", outputs[0])
                attention_mask = encoded["attention_mask"]

                if self.pooling == "mean":
                    mask_expanded = attention_mask.unsqueeze(-1).expand_as(hidden_states).float()
                    sum_embeddings = torch.sum(hidden_states * mask_expanded, dim=1)
                    sum_mask = mask_expanded.sum(dim=1).clamp(min=1e-9)
                    batch_embs = sum_embeddings / sum_mask
                elif self.pooling == "cls":
                    batch_embs = hidden_states[:, 0]
                elif self.pooling == "max":
                    batch_embs = torch.max(hidden_states, dim=1)[0]
                else:
                    batch_embs = hidden_states[:, 0]

                if self.normalize:
                    batch_embs = torch.nn.functional.normalize(batch_embs, p=2, dim=1)

                all_embeddings.append(batch_embs.cpu().numpy().astype(np.float32))

        if device.type == "cuda":
            torch.cuda.empty_cache()

        return np.vstack(all_embeddings)

    def get_feature_names_out(self, input_features: Optional[List[str]] = None) -> List[str]:
        """Return feature names for transformed outputs."""
        self._check_is_fitted()
        return [f"hf_embed_{i}" for i in range(self.n_features_out_)]
