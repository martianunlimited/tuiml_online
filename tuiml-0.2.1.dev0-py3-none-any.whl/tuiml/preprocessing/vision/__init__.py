"""Vision preprocessing module for TuiML."""

from .embeddings import HFImageEmbedder

__all__ = ["HFImageEmbedder"]
