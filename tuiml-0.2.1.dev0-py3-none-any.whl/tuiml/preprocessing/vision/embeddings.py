"""Hugging Face image embedding transformer for TuiML vision pipelines."""

from typing import Any, Dict, List, Optional, Union
import numpy as np
from PIL import Image
import os

from tuiml.base.preprocessing import Transformer, transformer

_EXTRA = "huggingface"


def _ensure_transformers():
    """Ensure transformers and torch are installed."""
    try:
        import torch  # noqa: F401
        import transformers  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            f"HFImageEmbedder requires 'transformers' and 'torch'. "
            f"Install them with: pip install 'tuiml[{_EXTRA}]'"
        ) from exc


@transformer(tags=["vision", "image", "embedding", "huggingface", "transformers"], version="1.0.0")
class HFImageEmbedder(Transformer):
    """Transform images into dense semantic embeddings using Hugging Face vision models.

    Converts image filepaths, PIL Images, or NumPy image arrays into fixed-size
    dense vectors using pretrained vision backbones (e.g. Vision Transformer ViT,
    ResNet, CLIP). The resulting feature matrix can be directly used by any
    downstream TuiML classifier, regressor, or clustering algorithm in a Workflow.

    Parameters
    ----------
    model_name : str, default="google/vit-base-patch16-224"
        Hugging Face Hub repository ID or path to a local directory with weights.
    batch_size : int, default=16
        Batch size used for image preprocessing and model inference.
    pooling : str, default="mean"
        Strategy to aggregate spatial token representations:
        ``"mean"``, ``"cls"``, or ``"pooler"`` (if model provides pooler_output).
    normalize : bool, default=True
        Whether to L2-normalize embeddings to unit length.
    device : str, default="auto"
        Compute device: ``"auto"`` (uses CUDA if available), ``"cuda"``, or ``"cpu"``.

    Attributes
    ----------
    n_features_out_ : int
        Dimensionality of the extracted embedding vectors (e.g. 768 for ViT-Base).
    model_ : AutoModel
        Loaded Hugging Face PyTorch vision model.
    processor_ : AutoImageProcessor
        Loaded Hugging Face image processor.
    """

    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Dict[str, Any]]:
        """Return parameter schema for introspection."""
        return {
            "model_name": {
                "type": "str",
                "default": "google/vit-base-patch16-224",
                "description": "Pretrained vision model name or checkpoint path.",
            },
            "batch_size": {
                "type": "int",
                "default": 16,
                "description": "Batch size for inference.",
            },
            "pooling": {
                "type": "str",
                "default": "mean",
                "options": ["mean", "cls", "pooler"],
                "description": "Pooling strategy for patch tokens.",
            },
            "normalize": {
                "type": "bool",
                "default": True,
                "description": "Whether to L2-normalize embeddings to unit length.",
            },
            "device": {
                "type": "str",
                "default": "auto",
                "options": ["auto", "cuda", "cpu"],
                "description": "Compute device.",
            },
        }

    def __init__(
        self,
        model_name: str = "google/vit-base-patch16-224",
        batch_size: int = 16,
        pooling: str = "mean",
        normalize: bool = True,
        device: str = "auto",
    ):
        super().__init__()
        self.model_name = model_name
        self.batch_size = batch_size
        self.pooling = pooling
        self.normalize = normalize
        self.device = device
        self.n_features_out_: Optional[int] = None

    def _resolve_device(self) -> str:
        """Pick device based on availability."""
        import torch

        if self.device == "auto":
            return "cuda" if torch.cuda.is_available() else "cpu"
        return self.device

    def _load_model(self):
        """Load image processor and vision model lazily."""
        _ensure_transformers()
        import torch
        from transformers import AutoImageProcessor, AutoModel

        device = self._resolve_device()
        self.processor_ = AutoImageProcessor.from_pretrained(self.model_name)
        self.model_ = AutoModel.from_pretrained(self.model_name)
        self.model_.eval()
        self.model_.to(device)

        # Determine feature dim
        config = self.model_.config
        self.n_features_out_ = getattr(config, "hidden_size", None) or getattr(
            config, "projection_dim", None
        )
        if not self.n_features_out_ and hasattr(config, "vision_config"):
            self.n_features_out_ = getattr(config.vision_config, "hidden_size", 768)
        if not self.n_features_out_:
            self.n_features_out_ = 768

    def _load_single_image(self, item: Any) -> Image.Image:
        """Convert item (path, ndarray, or PIL Image) to RGB PIL Image."""
        if isinstance(item, Image.Image):
            return item.convert("RGB")
        elif isinstance(item, str) and os.path.exists(item):
            return Image.open(item).convert("RGB")
        elif isinstance(item, np.ndarray):
            arr = item
            if arr.dtype in (np.float32, np.float64) and arr.max() <= 1.0:
                arr = (arr * 255).astype(np.uint8)
            else:
                arr = arr.astype(np.uint8)
            return Image.fromarray(arr).convert("RGB")
        else:
            raise ValueError(f"Unsupported image input type: {type(item)} or invalid path.")

    def fit(self, X: Any, y: Optional[Any] = None) -> "HFImageEmbedder":
        """Initialize the model and validate feature dimensionality."""
        self._load_model()
        self.is_fitted_ = True
        return self

    def transform(self, X: Any) -> np.ndarray:
        """Extract dense embeddings from input images."""
        if not hasattr(self, "is_fitted_") or not self.is_fitted_:
            self.fit(X)

        import torch

        # Normalize X to list of items
        if isinstance(X, np.ndarray) and X.ndim == 4:
            items = [X[i] for i in range(len(X))]
        elif isinstance(X, (list, tuple)):
            items = list(X)
        else:
            items = [X]

        device = self._resolve_device()
        all_embeddings: List[np.ndarray] = []

        for start_idx in range(0, len(items), self.batch_size):
            batch_items = items[start_idx : start_idx + self.batch_size]
            pil_images = [self._load_single_image(item) for item in batch_items]

            inputs = self.processor_(images=pil_images, return_tensors="pt").to(device)

            with torch.no_grad():
                outputs = self.model_(**inputs)

                if self.pooling == "pooler" and hasattr(outputs, "pooler_output") and outputs.pooler_output is not None:
                    batch_embs = outputs.pooler_output
                elif hasattr(outputs, "last_hidden_state"):
                    hidden = outputs.last_hidden_state
                    if self.pooling == "cls":
                        batch_embs = hidden[:, 0, :]
                    else:  # mean pooling
                        batch_embs = torch.mean(hidden, dim=1)
                elif hasattr(outputs, "pooler_output") and outputs.pooler_output is not None:
                    batch_embs = outputs.pooler_output
                else:
                    batch_embs = outputs[0]
                    if batch_embs.ndim == 3:
                        batch_embs = torch.mean(batch_embs, dim=1)

                if self.normalize:
                    batch_embs = torch.nn.functional.normalize(batch_embs, p=2, dim=-1)

                all_embeddings.append(batch_embs.detach().cpu().numpy())

        res = np.vstack(all_embeddings).astype(np.float32)
        if device == "cuda":
            torch.cuda.empty_cache()
        return res

    def get_feature_names_out(self, input_features: Optional[List[str]] = None) -> List[str]:
        """Return feature names for output embedding dimensions."""
        dim = self.n_features_out_ or 768
        prefix = self.model_name.split("/")[-1].replace("-", "_")
        return [f"{prefix}_emb_{i}" for i in range(dim)]
