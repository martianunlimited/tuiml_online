"""GPU memory monitoring, VRAM limit protection, and OOM recovery for Keras-Torch."""

import gc
import logging
from typing import Any, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)


def get_gpu_memory_info(device: Optional[Union[int, str]] = None) -> Dict[str, Any]:
    """Query current GPU VRAM status.

    Parameters
    ----------
    device : int or str, optional
        CUDA device index (e.g. 0) or device name. Defaults to current device.

    Returns
    -------
    dict
        Dictionary containing:
        - ``available``: bool, whether CUDA is active and available
        - ``device_name``: str or None
        - ``device_index``: int or None
        - ``total_mb``: float, total VRAM in megabytes
        - ``free_mb``: float, free VRAM in megabytes
        - ``allocated_mb``: float, currently allocated VRAM in megabytes
        - ``reserved_mb``: float, reserved memory by PyTorch caching allocator
    """
    try:
        import torch
        if not torch.cuda.is_available():
            return {
                "available": False,
                "device_name": None,
                "device_index": None,
                "total_mb": 0.0,
                "free_mb": 0.0,
                "allocated_mb": 0.0,
                "reserved_mb": 0.0,
                "message": "CUDA is not available. Running on CPU."
            }

        dev_idx = 0 if device is None else (int(device) if isinstance(device, int) else 0)
        free_bytes, total_bytes = torch.cuda.mem_get_info(dev_idx)
        allocated_bytes = torch.cuda.memory_allocated(dev_idx)
        reserved_bytes = torch.cuda.memory_reserved(dev_idx)
        dev_name = torch.cuda.get_device_name(dev_idx)

        return {
            "available": True,
            "device_name": dev_name,
            "device_index": dev_idx,
            "total_mb": round(total_bytes / (1024 * 1024), 2),
            "free_mb": round(free_bytes / (1024 * 1024), 2),
            "allocated_mb": round(allocated_bytes / (1024 * 1024), 2),
            "reserved_mb": round(reserved_bytes / (1024 * 1024), 2),
            "message": f"GPU {dev_name} (Device {dev_idx}): {round(free_bytes / (1024 * 1024), 1)} MB free of {round(total_bytes / (1024 * 1024), 1)} MB total."
        }
    except Exception as exc:
        return {
            "available": False,
            "error": str(exc),
            "total_mb": 0.0,
            "free_mb": 0.0,
            "allocated_mb": 0.0,
            "reserved_mb": 0.0,
            "message": f"Error querying GPU memory: {exc}"
        }


def cleanup_gpu_memory() -> None:
    """Run garbage collection and empty PyTorch CUDA cache."""
    gc.collect()
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()
    except Exception:
        pass


def estimate_model_vram(
    input_shape: Tuple[int, ...],
    batch_size: int,
    num_classes: int = 10,
    layers: Optional[List[Dict[str, Any]]] = None,
    n_params: Optional[int] = None,
) -> Dict[str, Any]:
    """Estimate peak VRAM required for training.

    Parameters
    ----------
    input_shape : tuple of int
        Shape of a single sample, e.g. (32, 32, 3) or (100,).
    batch_size : int
        Batch size.
    num_classes : int, default=10
        Number of output units.
    layers : list of dict, optional
        Layer specifications.
    n_params : int, optional
        Approximate parameter count if already known.

    Returns
    -------
    dict
        Estimated memory breakdown in MB:
        - ``model_weights_mb``
        - ``gradients_mb``
        - ``optimizer_states_mb`` (Adam uses ~2x weights for moments)
        - ``activations_mb``
        - ``batch_data_mb``
        - ``total_estimated_mb``
        - ``headroom_recommended_mb``
    """
    import numpy as np

    # Rough parameter count estimation if not provided
    if n_params is None:
        if layers:
            # Simple heuristic based on conv filters and dense units
            est_params = 0
            prev_dim = int(np.prod(input_shape))
            for layer in layers:
                cname = layer.get("class_name", "")
                cfg = layer.get("config", {})
                if cname in ("Conv2D", "Convolution2D"):
                    k = cfg.get("kernel_size", 3)
                    k_size = k * k if isinstance(k, int) else k[0] * k[1]
                    f = cfg.get("filters", 32)
                    est_params += prev_dim * k_size * f
                    prev_dim = f
                elif cname == "Dense":
                    u = cfg.get("units", 64)
                    est_params += prev_dim * u
                    prev_dim = u
                elif layer.get("module") == "applications":
                    # Pretrained backbone heuristic (e.g. MobileNet ~3.5M, ResNet50 ~25M)
                    c_lower = cname.lower()
                    if "mobilenet" in c_lower:
                        est_params += 4_000_000
                    elif "resnet50" in c_lower:
                        est_params += 25_000_000
                    elif "densenet121" in c_lower:
                        est_params += 8_000_000
                    else:
                        est_params += 10_000_000
            n_params = max(est_params, 50_000)
        else:
            n_params = 500_000

    # FP32: 4 bytes per float
    bytes_per_param = 4
    weights_bytes = n_params * bytes_per_param
    grads_bytes = weights_bytes
    # Adam stores m and v: 2 * weights_bytes
    optimizer_bytes = 2 * weights_bytes

    # Batch input data
    input_elements = int(np.prod(input_shape))
    batch_input_bytes = batch_size * input_elements * bytes_per_param

    # Forward activation memory (heuristic: ~4-8x batch input for CNNs)
    is_spatial = len(input_shape) >= 2
    act_multiplier = 12 if is_spatial else 2
    activations_bytes = batch_input_bytes * act_multiplier

    total_bytes = weights_bytes + grads_bytes + optimizer_bytes + activations_bytes + batch_input_bytes
    total_mb = total_bytes / (1024 * 1024)

    return {
        "n_params_estimated": n_params,
        "model_weights_mb": round(weights_bytes / (1024 * 1024), 2),
        "gradients_mb": round(grads_bytes / (1024 * 1024), 2),
        "optimizer_states_mb": round(optimizer_bytes / (1024 * 1024), 2),
        "activations_mb": round(activations_bytes / (1024 * 1024), 2),
        "batch_data_mb": round(batch_input_bytes / (1024 * 1024), 2),
        "total_estimated_mb": round(total_mb, 2),
        "headroom_recommended_mb": round(total_mb * 1.5, 2),
    }


def recommend_batch_size(
    input_shape: Tuple[int, ...],
    layers: Optional[List[Dict[str, Any]]] = None,
    safety_margin: float = 0.35,
) -> Dict[str, Any]:
    """Recommend optimal and safe batch sizes based on currently available VRAM.

    Parameters
    ----------
    input_shape : tuple of int
        Sample shape, e.g. (32, 32, 3).
    layers : list of dict, optional
        Layer specifications.
    safety_margin : float, default=0.35
        Fraction of free VRAM to keep untouched as safety buffer.

    Returns
    -------
    dict
        Recommendations including ``recommended_batch_size``,
        ``candidate_evaluations``, and ``free_vram_mb``.
    """
    mem_info = get_gpu_memory_info()
    if not mem_info.get("available", False):
        return {
            "recommended_batch_size": 32,
            "reason": "CPU execution; default batch size 32 is recommended.",
            "free_vram_mb": 0.0,
            "is_gpu": False
        }

    free_mb = mem_info["free_mb"]
    usable_mb = free_mb * (1.0 - safety_margin)

    candidates = [16, 32, 64, 128, 256, 512]
    evaluated = []
    recommended = 32

    for b in candidates:
        est = estimate_model_vram(input_shape=input_shape, batch_size=b, layers=layers)
        fits = est["total_estimated_mb"] <= usable_mb
        evaluated.append({
            "batch_size": b,
            "estimated_mb": est["total_estimated_mb"],
            "fits": fits
        })
        if fits:
            recommended = b

    return {
        "recommended_batch_size": recommended,
        "free_vram_mb": free_mb,
        "usable_vram_budget_mb": round(usable_mb, 2),
        "candidate_evaluations": evaluated,
        "is_gpu": True,
        "device_name": mem_info["device_name"]
    }


def check_vram_headroom(min_headroom_mb: float = 300.0) -> Tuple[bool, str]:
    """Check if free VRAM meets minimum safety headroom.

    Returns
    -------
    (bool, str)
        Tuple of (is_safe, message).
    """
    mem = get_gpu_memory_info()
    if not mem.get("available", False):
        return True, "Running on CPU (CUDA not active)."

    free_mb = mem["free_mb"]
    if free_mb < min_headroom_mb:
        msg = (
            f"Low VRAM warning: Only {free_mb:.1f} MB free VRAM available on {mem['device_name']}, "
            f"below the recommended {min_headroom_mb:.1f} MB safety headroom. Consider reducing "
            f"batch_size or running cleanup_gpu_memory()."
        )
        logger.warning(msg)
        return False, msg

    return True, f"VRAM headroom OK: {free_mb:.1f} MB free on {mem['device_name']}."
