"""Asynchronous model training and background job management for Keras-Torch."""

import logging
import threading
import uuid
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# In-memory registry of active and completed jobs
_JOBS: Dict[str, "TrainingJob"] = {}
_LOCK = threading.Lock()


class TrainingJob:
    """Handle to a background neural network training job."""

    def __init__(self, job_id: str, model: Any):
        self.job_id = job_id
        self.model = model
        self.status = "pending"  # pending, running, completed, failed, cancelled
        self.progress: Dict[str, Any] = {
            "status": "pending",
            "epoch": 0,
            "total_epochs": getattr(model, "epochs", 10),
            "progress_pct": 0.0,
            "elapsed_seconds": 0.0,
            "eta_seconds": 0.0,
            "metrics": {},
        }
        self.error: Optional[str] = None
        self._thread: Optional[threading.Thread] = None
        self._cancel_requested = threading.Event()
        self._done_event = threading.Event()

    def is_running(self) -> bool:
        """Check if the training job is currently executing."""
        return self.status == "running"

    def is_done(self) -> bool:
        """Check if the training job has completed, failed, or been cancelled."""
        return self.status in ("completed", "failed", "cancelled")

    def wait(self, timeout: Optional[float] = None) -> Any:
        """Wait for the training job to complete.

        Parameters
        ----------
        timeout : float, optional
            Maximum time in seconds to wait.

        Returns
        -------
        model
            The trained model instance.

        Raises
        ------
        TimeoutError
            If timeout expires before training completes.
        RuntimeError
            If the training job failed with an exception.
        """
        finished = self._done_event.wait(timeout=timeout)
        if not finished:
            raise TimeoutError(f"TrainingJob {self.job_id} did not finish within {timeout}s.")
        if self.status == "failed":
            raise RuntimeError(f"TrainingJob {self.job_id} failed: {self.error}")
        return self.model

    def result(self, timeout: Optional[float] = None) -> Any:
        """Alias for :meth:`wait`."""
        return self.wait(timeout=timeout)

    def cancel(self) -> bool:
        """Request cancellation of the training job."""
        if self.is_done():
            return False
        self._cancel_requested.set()
        self.status = "cancelled"
        self._done_event.set()
        return True

    def poll(self) -> Dict[str, Any]:
        """Return the current progress and status summary."""
        return {
            "job_id": self.job_id,
            "status": self.status,
            "is_running": self.is_running(),
            "progress": self.progress,
            "error": self.error,
        }


def start_async_training(
    model: Any,
    X: Any,
    y: Optional[Any] = None,
    job_id: Optional[str] = None,
    callbacks: Optional[List[Any]] = None,
    status_file: Optional[str] = None,
    **fit_kwargs,
) -> TrainingJob:
    """Launch model training asynchronously in a background worker thread.

    Parameters
    ----------
    model : _KerasTorchMixin
        The model instance to fit.
    X : array-like
        Training features.
    y : array-like, optional
        Target labels or values.
    job_id : str, optional
        Unique ID for this job. If None, a UUID is generated.
    callbacks : list, optional
        Additional Keras callbacks.
    status_file : str, optional
        Path to file where live progress JSON is mirrored.
    **fit_kwargs
        Additional arguments passed to :meth:`fit`.

    Returns
    -------
    TrainingJob
        Job handle for tracking and awaiting completion.
    """
    if job_id is None:
        job_id = f"kt_job_{uuid.uuid4().hex[:8]}"

    job = TrainingJob(job_id=job_id, model=model)
    with _LOCK:
        _JOBS[job_id] = job

    from tuiml.keras_torch.callbacks import TuiMLProgressCallback

    total_epochs = fit_kwargs.get("epochs", getattr(model, "epochs", 10))
    batch_size = fit_kwargs.get("batch_size", getattr(model, "batch_size", 32))
    n_samples = len(X) if hasattr(X, "__len__") else None

    def on_progress(data: Dict[str, Any]):
        job.progress = data

    progress_cb = TuiMLProgressCallback(
        total_epochs=total_epochs,
        total_samples=n_samples,
        batch_size=batch_size,
        status_file=status_file,
        on_progress=on_progress,
        verbose=getattr(model, "verbose", 1),
    )

    all_callbacks = list(callbacks or []) + [progress_cb]

    def _worker():
        job.status = "running"
        orig_cb = getattr(model, "callbacks", None)
        try:
            model.callbacks = all_callbacks
            model.fit(X, y, **fit_kwargs)
            job.status = "completed"
            job.progress["status"] = "completed"
        except Exception as exc:
            job.status = "failed"
            job.error = str(exc)
            job.progress["status"] = "failed"
            job.progress["error"] = str(exc)
            logger.error(f"Async training error for job {job_id}: {exc}", exc_info=True)
        finally:
            model.callbacks = orig_cb
            if hasattr(model, "progress_callback_"):
                model.progress_callback_.on_progress = None
            job._done_event.set()

    thread = threading.Thread(target=_worker, name=f"TuiML-Train-{job_id}", daemon=True)
    job._thread = thread
    thread.start()

    return job


def get_training_job(job_id: str) -> Optional[TrainingJob]:
    """Retrieve an active or finished training job by ID."""
    with _LOCK:
        return _JOBS.get(job_id)


def list_training_jobs() -> List[Dict[str, Any]]:
    """List all tracked training jobs and their statuses."""
    with _LOCK:
        return [job.poll() for job in _JOBS.values()]


def cancel_training_job(job_id: str) -> bool:
    """Cancel a training job by ID."""
    job = get_training_job(job_id)
    if job:
        return job.cancel()
    return False
