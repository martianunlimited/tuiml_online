"""Neural network wrappers for Keras (Torch backend)."""

from typing import Any, Dict, List, Optional, Union

import numpy as np

from tuiml.base.algorithms import Classifier, Regressor
from tuiml.keras_torch._base import _KerasTorchMixin, kt_classifier, kt_regressor


def _build_keras_layers(model: "keras.Sequential", layers_config: List[Dict[str, Any]]):
    """Dynamically add layers to a Keras Sequential model from configs."""
    import keras
    
    for layer_spec in layers_config:
        class_name = layer_spec.get("class_name")
        module_name = layer_spec.get("module", "layers")
        config = layer_spec.get("config", {})
        
        if not class_name:
            raise ValueError(f"Layer spec must contain 'class_name'. Got: {layer_spec}")
            
        if module_name == "layers":
            layer_class = getattr(keras.layers, class_name, None)
            if layer_class is None:
                raise ValueError(f"Unknown class {class_name} in keras.{module_name}")
            model.add(layer_class(**config))
        elif module_name == "applications":
            layer_class = getattr(keras.applications, class_name, None)
            if layer_class is None:
                raise ValueError(f"Unknown class {class_name} in keras.{module_name}")
            model.add(layer_class(**config))
        elif module_name in ("huggingface", "hf"):
            from tuiml.keras_torch.huggingface import build_hf_layer
            model.add(build_hf_layer(class_name, config))
        else:
            raise ValueError(f"Unknown Keras module: {module_name}")


@kt_classifier(tags=["neural", "deep_learning"])
class SequentialClassifier(_KerasTorchMixin, Classifier):
    """A Keras Sequential model wrapper for classification.
    
    Automatically constructs a Keras Sequential model based on the provided
    layer configurations. Automatically handles the input shape and the final
    output layer for classification (Dense with softmax/sigmoid).
    
    Parameters
    ----------
    layers : list of dict
        List of layer specifications. Each spec must have a ``"class_name"``
        and optionally a ``"config"`` dict. Example:
        ``[{"class_name": "Dense", "config": {"units": 64, "activation": "relu"}}]``
    optimizer : str or dict, default="adam"
        Optimizer name or configuration dict.
    loss : str or dict, default="sparse_categorical_crossentropy"
        Loss function name or configuration dict.
    metrics : list of str, default=["accuracy"]
        List of Keras metrics.
    epochs : int, default=10
        Number of epochs to train.
    batch_size : int, default=32
        Batch size.
    validation_split : float, default=0.0
        Fraction of the training data to be used as validation data.
    verbose : int, default=0
        Verbosity mode.
    """
    
    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Dict[str, Any]]:
        return {
            "layers": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "class_name": {"type": "string"},
                        "module": {"type": "string", "default": "layers"},
                        "config": {"type": "object"}
                    },
                    "required": ["class_name"]
                },
                "description": "List of Keras layer specifications"
            },
            "optimizer": {
                "type": ["string", "object"],
                "default": "adam",
                "description": "Optimizer name or config dict"
            },
            "loss": {
                "type": ["string", "object"],
                "default": "sparse_categorical_crossentropy",
                "description": "Loss function name or config dict"
            },
            "epochs": {
                "type": "integer",
                "default": 10,
                "description": "Number of training epochs"
            },
            "batch_size": {
                "type": "integer",
                "default": 32,
                "description": "Training batch size"
            },
            "validation_split": {
                "type": "number",
                "default": 0.0,
                "description": "Fraction of training data to use for validation"
            },
            "auto_batch_size": {
                "type": "boolean",
                "default": False,
                "description": "Automatically retry with halved batch size if CUDA OutOfMemory occurs"
            }
        }

    def __init__(
        self,
        layers: Optional[List[Dict[str, Any]]] = None,
        optimizer: Union[str, Dict[str, Any]] = "adam",
        loss: Union[str, Dict[str, Any]] = "sparse_categorical_crossentropy",
        metrics: Optional[List[str]] = None,
        epochs: int = 10,
        batch_size: int = 32,
        validation_split: float = 0.0,
        auto_batch_size: bool = False,
        status_file: Optional[str] = None,
        verbose: int = 0,
    ):
        super().__init__()
        self.layers = layers or []
        self.optimizer = optimizer
        self.loss = loss
        self.metrics = metrics or ["accuracy"]
        self.epochs = epochs
        self.batch_size = batch_size
        self.validation_split = validation_split
        self.auto_batch_size = auto_batch_size
        self.status_file = status_file
        self.verbose = verbose
        
    def _build_model(self, X: np.ndarray, y: Optional[np.ndarray] = None):
        import keras
        
        model = keras.Sequential()
        # Ensure we define the input shape on the first layer
        input_shape = X.shape[1:]
        model.add(keras.layers.Input(shape=input_shape))
        
        # Add user-defined hidden layers
        _build_keras_layers(model, self.layers)
        
        # Add the automatic output layer
        n_classes = len(self.classes_)
        if n_classes == 2:
            model.add(keras.layers.Dense(1, activation="sigmoid"))
            # Auto-adjust loss if user provided the default categorical one
            if self.loss == "sparse_categorical_crossentropy":
                self.loss = "binary_crossentropy"
        else:
            model.add(keras.layers.Dense(n_classes, activation="softmax"))
            
        model.compile(
            optimizer=self.optimizer,
            loss=self.loss,
            metrics=self.metrics
        )
        return model


@kt_regressor(tags=["neural", "deep_learning"])
class SequentialRegressor(_KerasTorchMixin, Regressor):
    """A Keras Sequential model wrapper for regression.
    
    Automatically constructs a Keras Sequential model based on the provided
    layer configurations. Automatically handles the input shape and the final
    output layer for regression (Dense).
    
    Parameters
    ----------
    layers : list of dict
        List of layer specifications. Each spec must have a ``"class_name"``
        and optionally a ``"config"`` dict. Example:
        ``[{"class_name": "Dense", "config": {"units": 64, "activation": "relu"}}]``
    optimizer : str or dict, default="adam"
        Optimizer name or configuration dict.
    loss : str or dict, default="mean_squared_error"
        Loss function name or configuration dict.
    metrics : list of str, default=["mean_squared_error"]
        List of Keras metrics.
    epochs : int, default=10
        Number of epochs to train.
    batch_size : int, default=32
        Batch size.
    validation_split : float, default=0.0
        Fraction of the training data to be used as validation data.
    verbose : int, default=0
        Verbosity mode.
    """
    
    @classmethod
    def get_parameter_schema(cls) -> Dict[str, Dict[str, Any]]:
        return {
            "layers": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "class_name": {"type": "string"},
                        "module": {"type": "string", "default": "layers"},
                        "config": {"type": "object"}
                    },
                    "required": ["class_name"]
                },
                "description": "List of Keras layer specifications"
            },
            "optimizer": {
                "type": ["string", "object"],
                "default": "adam",
                "description": "Optimizer name or config dict"
            },
            "loss": {
                "type": ["string", "object"],
                "default": "mean_squared_error",
                "description": "Loss function name or config dict"
            },
            "epochs": {
                "type": "integer",
                "default": 10,
                "description": "Number of training epochs"
            },
            "batch_size": {
                "type": "integer",
                "default": 32,
                "description": "Training batch size"
            },
            "validation_split": {
                "type": "number",
                "default": 0.0,
                "description": "Fraction of training data to use for validation"
            },
            "auto_batch_size": {
                "type": "boolean",
                "default": False,
                "description": "Automatically retry with halved batch size if CUDA OutOfMemory occurs"
            }
        }

    def __init__(
        self,
        layers: Optional[List[Dict[str, Any]]] = None,
        optimizer: Union[str, Dict[str, Any]] = "adam",
        loss: Union[str, Dict[str, Any]] = "mean_squared_error",
        metrics: Optional[List[str]] = None,
        epochs: int = 10,
        batch_size: int = 32,
        validation_split: float = 0.0,
        auto_batch_size: bool = False,
        status_file: Optional[str] = None,
        verbose: int = 0,
    ):
        super().__init__()
        self.layers = layers or []
        self.optimizer = optimizer
        self.loss = loss
        self.metrics = metrics or ["mean_squared_error"]
        self.epochs = epochs
        self.batch_size = batch_size
        self.validation_split = validation_split
        self.auto_batch_size = auto_batch_size
        self.status_file = status_file
        self.verbose = verbose
        
    def _build_model(self, X: np.ndarray, y: Optional[np.ndarray] = None):
        import keras
        
        model = keras.Sequential()
        # Ensure we define the input shape on the first layer
        input_shape = X.shape[1:]
        model.add(keras.layers.Input(shape=input_shape))
        
        # Add user-defined hidden layers
        _build_keras_layers(model, self.layers)
        
        # Add the automatic output layer (1 output for standard regression)
        # If multi-output regression is needed in future, y.shape[1] can be used.
        out_dim = y.shape[1] if y.ndim > 1 else 1
        model.add(keras.layers.Dense(out_dim))
            
        model.compile(
            optimizer=self.optimizer,
            loss=self.loss,
            metrics=self.metrics
        )
        return model
