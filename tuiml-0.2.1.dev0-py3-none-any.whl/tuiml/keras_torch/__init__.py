"""Keras 3 (Torch backend) wrappers and neural toolkit for TuiML.

This submodule provides deep learning algorithms using Keras 3 with the PyTorch
backend, cleanly exposing them to the TuiML ecosystem with automatic registration,
hardware/VRAM monitoring, real-time progress callbacks, explainability (Grad-CAM),
background async training, and GPU-accelerated augmentation.
"""

import os
# Ensure torch backend is configured
if "KERAS_BACKEND" not in os.environ:
    os.environ["KERAS_BACKEND"] = "torch"

from tuiml.keras_torch.neural import SequentialClassifier, SequentialRegressor
from tuiml.keras_torch.memory import (
    get_gpu_memory_info,
    estimate_model_vram,
    recommend_batch_size,
    cleanup_gpu_memory,
    check_vram_headroom,
)
from tuiml.keras_torch.callbacks import TuiMLProgressCallback
from tuiml.keras_torch.explainability import generate_gradcam, visualize_activations
from tuiml.keras_torch.async_training import (
    TrainingJob,
    start_async_training,
    get_training_job,
    list_training_jobs,
    cancel_training_job,
)
from tuiml.keras_torch.augmentation import (
    patch_keras_torch_affine,
    unpatch_keras_torch_affine,
    is_affine_patched,
    enable_gpu_augmentation_speedups,
)
from tuiml.keras_torch.huggingface import (
    build_hf_layer,
    list_popular_hf_models,
    get_hf_transformer_layer,
)
from tuiml.preprocessing.text.embeddings import HFTextEmbedder

# Activate GPU affine acceleration patch on import
try:
    patch_keras_torch_affine()
except Exception:
    pass

__all__ = [
    "SequentialClassifier",
    "SequentialRegressor",
    "get_gpu_memory_info",
    "estimate_model_vram",
    "recommend_batch_size",
    "cleanup_gpu_memory",
    "check_vram_headroom",
    "TuiMLProgressCallback",
    "generate_gradcam",
    "visualize_activations",
    "TrainingJob",
    "start_async_training",
    "get_training_job",
    "list_training_jobs",
    "cancel_training_job",
    "patch_keras_torch_affine",
    "unpatch_keras_torch_affine",
    "is_affine_patched",
    "enable_gpu_augmentation_speedups",
    "build_hf_layer",
    "list_popular_hf_models",
    "get_hf_transformer_layer",
    "HFTextEmbedder",
]
