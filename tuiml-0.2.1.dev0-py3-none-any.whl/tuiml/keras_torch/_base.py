"""Shared machinery for the Keras 3 (Torch backend) bridge.

This module centralizes everything the ``tuiml.keras_torch`` wrappers need:

* **Namespaced registration decorators** (``kt_classifier`` etc.) that register
  each wrapper into the hub under a ``keras_torch.<ClassName>`` key.
* **Wrapper mixins** that implement ``fit`` / ``predict`` by delegating to a
  compiled Keras model.
"""

import os
from typing import Any, Dict, List, Optional

import numpy as np

from tuiml.base.algorithms import classifier, regressor

NAMESPACE = "keras_torch"
_EXTRA = "keras-torch"


def _ensure_keras_torch(cls_name: str) -> None:
    """Raise an actionable error if Keras or Torch is not importable, and activate optimizations."""
    try:
        os.environ["KERAS_BACKEND"] = "torch"
        import keras  # noqa: F401
        import torch  # noqa: F401
        from tuiml.keras_torch.augmentation import patch_keras_torch_affine
        patch_keras_torch_affine()
    except ImportError as exc:
        raise ImportError(
            f"{cls_name} requires keras and torch, which are not installed. "
            f"Install them with:  pip install 'tuiml[{_EXTRA}]'"
        ) from exc


def _namespaced(base_decorator):
    """Wrap a base tuiml decorator so it registers under ``keras_torch.<ClassName>``."""

    def factory(tags: Optional[List[str]] = None, version: str = "1.0.0"):
        def decorate(cls):
            key = f"{NAMESPACE}.{cls.__name__}"
            merged_tags = list(tags or [])
            if NAMESPACE not in merged_tags:
                merged_tags.append(NAMESPACE)
            return base_decorator(name=key, tags=merged_tags, version=version)(cls)

        return decorate

    return factory


kt_classifier = _namespaced(classifier)
kt_regressor = _namespaced(regressor)


class _KerasTorchMixin:
    """Implements ``fit`` / ``predict`` by delegating to a Keras model.

    Concrete subclasses must implement :meth:`_build_model`, which returns a
    compiled Keras model configured from the wrapper's constructor parameters
    and the input data shapes.
    """

    _requires = "keras-torch"
    _extra = _EXTRA

    def _build_model(self, X: np.ndarray, y: Optional[np.ndarray] = None):
        """Return a compiled Keras model.

        This method is called during ``fit``. It should inspect ``X`` and ``y``
        to determine input shapes and number of classes, then build and compile
        the model.
        """
        raise NotImplementedError

    def _prepare_y(self, y: np.ndarray) -> np.ndarray:
        """Prepare target values for Keras. Can be overridden."""
        from tuiml.base.algorithms import Classifier
        if isinstance(self, Classifier):
            # Map classes to contiguous indices [0, n_classes-1]
            return np.searchsorted(self.classes_, y)
        return y

    def fit(self, X: np.ndarray, y: Optional[np.ndarray] = None, **kwargs) -> "Any":
        """Fit the backing Keras model."""
        _ensure_keras_torch(type(self).__name__)
        
        # Ensure numeric arrays
        X = np.asarray(X, dtype=np.float32)
        if y is not None:
            y = np.asarray(y)
            # For classifiers, discover classes
            from tuiml.base.algorithms import Classifier
            if isinstance(self, Classifier):
                self.classes_ = np.unique(y)
            y_prepared = self._prepare_y(y)
        else:
            y_prepared = None

        # VRAM protection and cleanup before allocation
        from tuiml.keras_torch.memory import cleanup_gpu_memory, check_vram_headroom, get_gpu_memory_info
        cleanup_gpu_memory()
        check_vram_headroom(min_headroom_mb=250.0)

        self.model_ = self._build_model(X, y)

        fit_kwargs = {}
        if hasattr(self, "epochs"):
            fit_kwargs["epochs"] = getattr(self, "epochs")
        if hasattr(self, "batch_size"):
            fit_kwargs["batch_size"] = getattr(self, "batch_size")
        if hasattr(self, "validation_split"):
            fit_kwargs["validation_split"] = getattr(self, "validation_split")
        fit_kwargs.update(kwargs)
        
        callbacks = list(getattr(self, "callbacks", None) or [])
        verbosity = getattr(self, "verbose", 0)

        # Attach TuiML progress callback for speed and ETA reporting if verbose
        from tuiml.keras_torch.callbacks import TuiMLProgressCallback
        has_tuiml_cb = any(isinstance(cb, TuiMLProgressCallback) for cb in callbacks)
        if not has_tuiml_cb:
            p_cb = TuiMLProgressCallback(
                total_epochs=fit_kwargs.get("epochs", 10),
                total_samples=len(X),
                batch_size=fit_kwargs.get("batch_size", 32),
                status_file=getattr(self, "status_file", None),
                verbose=verbosity,
            )
            callbacks.append(p_cb)
            self.progress_callback_ = p_cb

        # Silence raw Keras stdout if our custom callback handles reporting
        fit_kwargs["verbose"] = 0 if verbosity <= 1 else verbosity

        try:
            history = self.model_.fit(X, y_prepared, callbacks=callbacks, **fit_kwargs)
        except Exception as exc:
            is_oom = "out of memory" in str(exc).lower() or type(exc).__name__ == "OutOfMemoryError"
            if is_oom:
                cleanup_gpu_memory()
                current_bs = fit_kwargs.get("batch_size", 32)
                auto_bs = getattr(self, "auto_batch_size", False) or getattr(self, "retry_on_oom", False)
                if auto_bs and current_bs > 1:
                    new_bs = max(1, current_bs // 2)
                    import logging
                    logging.getLogger(__name__).warning(
                        f"CUDA OutOfMemory detected at batch_size={current_bs}. "
                        f"Auto-retrying with halved batch_size={new_bs}..."
                    )
                    self.batch_size = new_bs
                    fit_kwargs["batch_size"] = new_bs
                    self.model_ = self._build_model(X, y)
                    history = self.model_.fit(X, y_prepared, callbacks=callbacks, **fit_kwargs)
                else:
                    mem_info = get_gpu_memory_info()
                    raise RuntimeError(
                        f"CUDA OutOfMemoryError during training (batch_size={current_bs}). "
                        f"Free VRAM: {mem_info.get('free_mb', 'N/A')} MB. "
                        f"Suggestions: 1) Reduce batch_size to {max(1, current_bs // 2)}, "
                        f"2) Use a smaller model architecture, or 3) Set auto_batch_size=True on {type(self).__name__}."
                    ) from exc
            else:
                raise

        self.history_ = history.history
        self._is_fitted = True
        return self

    def partial_fit(
        self,
        X: np.ndarray,
        y: Optional[np.ndarray] = None,
        classes: Optional[np.ndarray] = None,
        return_dict: bool = True,
        **kwargs,
    ) -> "Any":
        """Update the model with a single batch of samples (online / incremental learning).

        Follows the standard TuiML and scikit-learn online learning convention
        used across SGDClassifier, MultilayerPerceptronClassifier, NaiveBayes, etc.
        Executes a single stochastic gradient descent update step on the provided batch.

        Parameters
        ----------
        X : np.ndarray
            Batch of training samples with shape (batch_size, ...).
        y : np.ndarray, optional
            Batch of target labels or values.
        classes : array-like, optional
            Full array of expected class labels (classifiers only). Must be passed
            on the first call if the initial batch does not contain all classes.
        return_dict : bool, default=True
            Whether to return metrics as a dict and update ``last_batch_metrics_``.
        **kwargs
            Additional arguments forwarded to Keras train_on_batch.

        Returns
        -------
        self : _KerasTorchMixin
            The updated model instance.
        """
        _ensure_keras_torch(type(self).__name__)

        X = np.asarray(X, dtype=np.float32)
        from tuiml.base.algorithms import Classifier
        is_classifier = isinstance(self, Classifier)

        if not getattr(self, "_is_fitted", False) or not hasattr(self, "model_"):
            if is_classifier:
                if classes is not None:
                    self.classes_ = np.sort(np.unique(classes))
                elif y is not None:
                    self.classes_ = np.sort(np.unique(y))
                else:
                    raise ValueError(
                        "Classes must be provided via 'classes' or discovered from 'y' "
                        "on the first partial_fit call."
                    )

            from tuiml.keras_torch.memory import cleanup_gpu_memory, check_vram_headroom
            cleanup_gpu_memory()
            check_vram_headroom(min_headroom_mb=200.0)

            self.model_ = self._build_model(X, y)
            self._is_fitted = True
            self.n_iter_ = 0
            self.n_samples_seen_ = 0

        # Prepare y
        if y is not None:
            y = np.asarray(y)
            y_prepared = self._prepare_y(y) if is_classifier else y
        else:
            y_prepared = None

        # Execute single batch gradient update
        metrics = self.model_.train_on_batch(X, y_prepared, return_dict=return_dict, **kwargs)

        self.n_iter_ = getattr(self, "n_iter_", 0) + 1
        self.n_samples_seen_ = getattr(self, "n_samples_seen_", 0) + len(X)
        self.last_batch_metrics_ = metrics

        return self

    def fit_one_batch(
        self,
        X: np.ndarray,
        y: Optional[np.ndarray] = None,
        classes: Optional[np.ndarray] = None,
        **kwargs,
    ) -> "Any":
        """Alias for :meth:`partial_fit` to update weights on a single batch."""
        return self.partial_fit(X, y, classes=classes, **kwargs)

    def train_on_batch(
        self,
        X: np.ndarray,
        y: Optional[np.ndarray] = None,
        **kwargs,
    ) -> Any:
        """Keras-style alias for :meth:`partial_fit`."""
        return self.partial_fit(X, y, **kwargs)

    def test_on_batch(
        self,
        X: np.ndarray,
        y: Optional[np.ndarray] = None,
        return_dict: bool = True,
        **kwargs,
    ) -> Any:
        """Evaluate the model on a single batch without updating weights."""
        self._check_is_fitted()
        X = np.asarray(X, dtype=np.float32)
        from tuiml.base.algorithms import Classifier
        if y is not None and isinstance(self, Classifier):
            y_prep = self._prepare_y(np.asarray(y))
        else:
            y_prep = y
        return self.model_.test_on_batch(X, y_prep, return_dict=return_dict, **kwargs)

    def fit_async(
        self,
        X: np.ndarray,
        y: Optional[np.ndarray] = None,
        job_id: Optional[str] = None,
        status_file: Optional[str] = None,
        **fit_kwargs,
    ) -> Any:
        """Asynchronously fit the backing model in a background thread.

        Parameters
        ----------
        X : array-like
            Training features.
        y : array-like, optional
            Target labels or values.
        job_id : str, optional
            Custom identifier for this training job.
        status_file : str, optional
            Path to file where live progress JSON is mirrored.
        **fit_kwargs
            Additional arguments passed to fit.

        Returns
        -------
        TrainingJob
            Handle to the background training job.
        """
        from tuiml.keras_torch.async_training import start_async_training
        return start_async_training(self, X, y, job_id=job_id, status_file=status_file, **fit_kwargs)

    def explain(
        self,
        image: np.ndarray,
        target_class: Optional[int] = None,
        layer_name: Optional[str] = None,
        colormap: str = "jet",
        alpha: float = 0.45,
        save_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Generate Grad-CAM explanation for an input image.

        Parameters
        ----------
        image : np.ndarray
            Single image with shape (H, W, C) or (1, H, W, C).
        target_class : int, optional
            Class index to explain. If None, uses top predicted class.
        layer_name : str, optional
            Target conv layer name. If None, picks the last conv layer.
        colormap : str, default="jet"
            Matplotlib colormap for heatmap.
        alpha : float, default=0.45
            Overlay opacity factor.
        save_path : str, optional
            Path to save the 3-panel explanation plot.

        Returns
        -------
        dict
            Dict containing heatmap, overlay, predicted_class, and figure_path.
        """
        self._check_is_fitted()
        from tuiml.keras_torch.explainability import generate_gradcam
        return generate_gradcam(
            self,
            image=image,
            target_class=target_class,
            layer_name=layer_name,
            colormap=colormap,
            alpha=alpha,
            save_path=save_path,
        )

    def visualize_activations(
        self,
        image: np.ndarray,
        layer_name: Optional[str] = None,
        max_features: int = 16,
        save_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Extract and visualize intermediate layer activations for an input sample.

        Parameters
        ----------
        image : np.ndarray
            Input image.
        layer_name : str, optional
            Layer to visualize.
        max_features : int, default=16
            Max number of filter feature maps to plot.
        save_path : str, optional
            Path to save the feature map grid plot.

        Returns
        -------
        dict
            Dict containing activations metadata and figure_path.
        """
        self._check_is_fitted()
        from tuiml.keras_torch.explainability import visualize_activations
        return visualize_activations(
            self,
            image=image,
            layer_name=layer_name,
            max_features=max_features,
            save_path=save_path,
        )

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict with the backing Keras model."""
        self._check_is_fitted()
        X = np.asarray(X, dtype=np.float32)
        verbosity = getattr(self, "verbose", 0)
        
        preds = self.model_.predict(X, verbose=verbosity)
        
        from tuiml.base.algorithms import Classifier
        if isinstance(self, Classifier):
            # If the model output is 2D (probabilities)
            if preds.ndim == 2 and preds.shape[1] > 1:
                return self.classes_[np.argmax(preds, axis=1)]
            elif preds.ndim == 2 and preds.shape[1] == 1:
                return self.classes_[(preds > 0.5).astype(int).flatten()]
            return self.classes_[preds]
        
        # Regressor
        return preds.flatten() if preds.ndim == 2 and preds.shape[1] == 1 else preds

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Predict class probabilities."""
        self._check_is_fitted()
        from tuiml.base.algorithms import Classifier
        if not isinstance(self, Classifier):
            raise AttributeError(f"{self.__class__.__name__} is a Regressor and does not support predict_proba.")
            
        X = np.asarray(X, dtype=np.float32)
        verbosity = getattr(self, "verbose", 0)
        
        preds = self.model_.predict(X, verbose=verbosity)
        if preds.ndim == 2 and preds.shape[1] == 1:
            # Binary classification with a single sigmoid output
            return np.hstack([1 - preds, preds])
        return preds

    def get_params(self, deep: bool = True) -> Dict[str, Any]:
        """Return constructor parameters."""
        return {
            key: value
            for key, value in self.__dict__.items()
            if not key.startswith("_") and not key.endswith("_")
        }
