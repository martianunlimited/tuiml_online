"""Explainability tools for Keras-Torch: Grad-CAM and activation visualization."""

import logging
import os
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np

logger = logging.getLogger(__name__)


def _find_conv_layer(model: Any, layer_name: Optional[str] = None) -> Tuple[Any, str]:
    """Recursively search for a convolutional layer in a Keras/Torch model."""
    keras_model = getattr(model, "model_", model)

    if layer_name:
        # Check top-level layers
        for layer in getattr(keras_model, "layers", []):
            if layer.name == layer_name:
                return layer, layer_name
            # Check nested models/applications
            if hasattr(layer, "layers"):
                for sub in layer.layers:
                    if sub.name == layer_name:
                        return sub, layer_name
        raise ValueError(f"Could not find layer with name '{layer_name}' in model.")

    # Auto-detect: find the last Conv2D / convolution layer
    candidate = None
    candidate_name = None

    def search_layers(layers):
        nonlocal candidate, candidate_name
        for l in layers:
            cname = l.__class__.__name__.lower()
            lname = getattr(l, "name", "").lower()
            if "conv" in cname or "conv" in lname:
                candidate = l
                candidate_name = l.name
            if hasattr(l, "layers"):
                search_layers(l.layers)

    search_layers(getattr(keras_model, "layers", []))

    if candidate is None:
        raise ValueError(
            "Could not automatically detect any Convolutional layer in the model for Grad-CAM. "
            "Please specify `layer_name` explicitly."
        )

    return candidate, candidate_name


def generate_gradcam(
    model: Any,
    image: np.ndarray,
    target_class: Optional[int] = None,
    layer_name: Optional[str] = None,
    colormap: str = "jet",
    alpha: float = 0.45,
    save_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Generate Grad-CAM (Class Activation Map) for an input image.

    Parameters
    ----------
    model : SequentialClassifier or keras.Model
        Fitted model.
    image : np.ndarray
        Single input image with shape (H, W, C) or (1, H, W, C).
    target_class : int, optional
        Target class index. If None, the top predicted class is used.
    layer_name : str, optional
        Name of the convolutional layer to compute gradients w.r.t.
        If None, automatically picks the last convolutional layer.
    colormap : str, default="jet"
        Matplotlib colormap name.
    alpha : float, default=0.45
        Overlay opacity blending factor between 0.0 and 1.0.
    save_path : str, optional
        If provided, saves the visualization figure to disk.

    Returns
    -------
    dict
        Dictionary containing:
        - ``heatmap``: np.ndarray (H, W) normalized to [0, 1]
        - ``overlay``: np.ndarray (H, W, 3) superimposed RGB image
        - ``predicted_class``: int
        - ``target_class``: int
        - ``class_probability``: float
        - ``layer_name``: str
        - ``figure_path``: str or None
    """
    import torch
    import torch.nn.functional as F

    keras_model = getattr(model, "model_", model)
    target_layer, found_layer_name = _find_conv_layer(keras_model, layer_name)

    img_arr = np.asarray(image, dtype=np.float32)
    if img_arr.ndim == 3:
        img_arr = np.expand_dims(img_arr, axis=0)
    elif img_arr.ndim != 4 or img_arr.shape[0] != 1:
        raise ValueError(f"Expected image with shape (H, W, C) or (1, H, W, C), got {img_arr.shape}")

    _, height, width, channels = img_arr.shape

    # Normalize image to [0, 1] for visualization
    disp_img = img_arr[0].copy()
    img_min, img_max = disp_img.min(), disp_img.max()
    if img_max > img_min:
        disp_img = (disp_img - img_min) / (img_max - img_min)
    disp_img = np.clip(disp_img, 0.0, 1.0)

    # PyTorch hooks for capturing activations and gradients
    activations = []
    def forward_hook(module, inp, out):
        activations.append(out)

    handle = target_layer.register_forward_hook(forward_hook)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    x_tensor = torch.tensor(img_arr, dtype=torch.float32, device=device, requires_grad=True)

    try:
        with torch.enable_grad():
            preds = keras_model(x_tensor)
            if isinstance(preds, (list, tuple)):
                preds = preds[0]

            probs = preds.detach().cpu().numpy().flatten()
            if len(probs) == 1:
                # Binary classification sigmoid
                pred_class = int(probs[0] > 0.5)
                pred_prob = float(probs[0] if pred_class == 1 else (1.0 - probs[0]))
            else:
                pred_class = int(np.argmax(probs))
                pred_prob = float(probs[pred_class])

            chosen_class = pred_class if target_class is None else int(target_class)

            if len(probs) == 1:
                score = preds[0, 0] if chosen_class == 1 else -preds[0, 0]
            else:
                score = preds[0, chosen_class]

            if not activations:
                raise RuntimeError(f"Target layer {found_layer_name} did not produce forward activations.")

            act = activations[0]
            act.retain_grad()
            score.backward()

            grads = act.grad
            if grads is None:
                raise RuntimeError(f"Gradients w.r.t {found_layer_name} are None. Ensure layer is trainable.")

            # Keras layers might output (B, H, W, C) or (B, C, H, W)
            if act.ndim == 4:
                if act.shape[1] == channels or act.shape[-1] > act.shape[1]:
                    # Shape is (B, H, W, C)
                    weights = torch.mean(grads, dim=(1, 2), keepdim=True)  # (1, 1, 1, C)
                    cam = torch.relu(torch.sum(weights * act, dim=-1))    # (1, H, W)
                else:
                    # Shape is (B, C, H, W)
                    weights = torch.mean(grads, dim=(2, 3), keepdim=True)  # (1, C, 1, 1)
                    cam = torch.relu(torch.sum(weights * act, dim=1))     # (1, H, W)
            else:
                cam = torch.relu(act)

            # Interpolate to input resolution
            cam_upsampled = F.interpolate(
                cam.unsqueeze(1),
                size=(height, width),
                mode="bilinear",
                align_corners=False
            ).squeeze().detach().cpu().numpy()

            # Normalize heatmap to [0, 1]
            cam_min, cam_max = cam_upsampled.min(), cam_upsampled.max()
            if cam_max > cam_min:
                heatmap = (cam_upsampled - cam_min) / (cam_max - cam_min)
            else:
                heatmap = np.zeros_like(cam_upsampled)

    finally:
        handle.remove()

    # Generate colorized overlay using matplotlib colormap
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    try:
        cmap_fn = matplotlib.colormaps[colormap]
    except Exception:
        cmap_fn = plt.get_cmap(colormap)

    heatmap_colored = cmap_fn(heatmap)[:, :, :3]  # (H, W, 3) in [0, 1]

    if disp_img.shape[-1] == 1:
        disp_img_rgb = np.repeat(disp_img, 3, axis=-1)
    else:
        disp_img_rgb = disp_img[:, :, :3]

    overlay = (1.0 - alpha) * disp_img_rgb + alpha * heatmap_colored
    overlay = np.clip(overlay, 0.0, 1.0)

    # Plot and save if requested
    fig_path = None
    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        fig, axes = plt.subplots(1, 3, figsize=(12, 4))
        axes[0].imshow(disp_img_rgb)
        axes[0].set_title("Input Image")
        axes[0].axis("off")

        im_heat = axes[1].imshow(heatmap, cmap=colormap)
        axes[1].set_title(f"Grad-CAM ({found_layer_name})")
        axes[1].axis("off")
        fig.colorbar(im_heat, ax=axes[1], fraction=0.046, pad=0.04)

        axes[2].imshow(overlay)
        axes[2].set_title(f"Class {chosen_class} ({pred_prob * 100:.1f}%)")
        axes[2].axis("off")

        plt.tight_layout()
        plt.savefig(save_path, dpi=200, bbox_inches="tight")
        plt.close(fig)
        fig_path = save_path

    return {
        "heatmap": heatmap,
        "overlay": overlay,
        "predicted_class": pred_class,
        "target_class": chosen_class,
        "class_probability": round(pred_prob, 4),
        "layer_name": found_layer_name,
        "figure_path": fig_path,
    }


def visualize_activations(
    model: Any,
    image: np.ndarray,
    layer_name: Optional[str] = None,
    max_features: int = 16,
    save_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Extract and plot intermediate feature map activations for an input sample.

    Parameters
    ----------
    model : SequentialClassifier or keras.Model
        Fitted model.
    image : np.ndarray
        Single input sample (H, W, C) or (1, H, W, C).
    layer_name : str, optional
        Target layer name. If None, picks the first convolutional layer.
    max_features : int, default=16
        Maximum number of feature maps to display in grid.
    save_path : str, optional
        Path to save plot.

    Returns
    -------
    dict
        Dictionary containing ``activations`` array, ``layer_name``, and ``figure_path``.
    """
    import torch
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    keras_model = getattr(model, "model_", model)
    target_layer, found_name = _find_conv_layer(keras_model, layer_name)

    img_arr = np.asarray(image, dtype=np.float32)
    if img_arr.ndim == 3:
        img_arr = np.expand_dims(img_arr, axis=0)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    x_tensor = torch.tensor(img_arr, dtype=torch.float32, device=device)

    acts = []
    def hook_fn(mod, inp, out):
        acts.append(out.detach().cpu())

    handle = target_layer.register_forward_hook(hook_fn)
    try:
        with torch.no_grad():
            keras_model(x_tensor)
    finally:
        handle.remove()

    if not acts:
        raise RuntimeError(f"No activations captured for layer {found_name}.")

    feature_maps = acts[0][0].numpy()  # (H, W, C) or (C, H, W)
    if feature_maps.ndim == 3 and feature_maps.shape[0] < feature_maps.shape[-1]:
        # (C, H, W) -> transpose to (H, W, C)
        feature_maps = np.transpose(feature_maps, (1, 2, 0))

    n_features = min(feature_maps.shape[-1], max_features)
    n_cols = 4
    n_rows = int(np.ceil(n_features / n_cols))

    fig_path = None
    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 2.5, n_rows * 2.5))
        axes_flat = axes.flatten() if hasattr(axes, "flatten") else [axes]

        for i in range(len(axes_flat)):
            if i < n_features:
                fmap = feature_maps[:, :, i]
                axes_flat[i].imshow(fmap, cmap="viridis")
                axes_flat[i].set_title(f"Filter {i}", fontsize=9)
            axes_flat[i].axis("off")

        plt.suptitle(f"Activations: {found_name} (Top {n_features} filters)", fontsize=12)
        plt.tight_layout()
        plt.savefig(save_path, dpi=200, bbox_inches="tight")
        plt.close(fig)
        fig_path = save_path

    return {
        "layer_name": found_name,
        "n_channels": feature_maps.shape[-1],
        "feature_maps_shape": list(feature_maps.shape),
        "figure_path": fig_path,
    }
