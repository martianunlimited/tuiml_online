"""Hugging Face integration for Keras 3 with PyTorch backend in TuiML.

Provides seamless integration of Hugging Face transformer and vision backbones
into Keras Sequential and Functional architectures, wrapped via PyTorch runtime
and TorchModuleWrapper.
"""

from typing import Any, Dict, List, Optional, Union
import numpy as np

_EXTRA = "huggingface"


def _ensure_transformers():
    """Ensure transformers and torch are installed."""
    try:
        import torch  # noqa: F401
        import transformers  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            f"Hugging Face integration requires 'transformers' and 'torch'. "
            f"Install them with: pip install 'tuiml[{_EXTRA}]'"
        ) from exc


POPULAR_HF_MODELS: List[Dict[str, Any]] = [
    {
        "name": "sentence-transformers/all-MiniLM-L6-v2",
        "task": "sentence-embeddings",
        "modality": "text",
        "hidden_size": 384,
        "params": "22M",
        "description": "Fast, high-quality sentence embeddings; ideal for classification and feature extraction."
    },
    {
        "name": "distilbert-base-uncased",
        "task": "masked-lm",
        "modality": "text",
        "hidden_size": 768,
        "params": "66M",
        "description": "Lightweight, fast transformer; 40% smaller and 60% faster than BERT with 97% performance."
    },
    {
        "name": "bert-base-uncased",
        "task": "masked-lm",
        "modality": "text",
        "hidden_size": 768,
        "params": "110M",
        "description": "Standard bidirectional transformer encoder for NLP classification."
    },
    {
        "name": "roberta-base",
        "task": "masked-lm",
        "modality": "text",
        "hidden_size": 768,
        "params": "125M",
        "description": "Robustly optimized BERT approach with enhanced representations."
    },
    {
        "name": "albert-base-v2",
        "task": "masked-lm",
        "modality": "text",
        "hidden_size": 768,
        "params": "12M",
        "description": "Extremely parameter-efficient transformer with cross-layer parameter sharing."
    },
    {
        "name": "google/vit-base-patch16-224",
        "task": "image-classification",
        "modality": "vision",
        "hidden_size": 768,
        "params": "86M",
        "description": "Vision Transformer for 224x224 images with 16x16 patch resolution."
    },
    {
        "name": "microsoft/resnet-50",
        "task": "image-classification",
        "modality": "vision",
        "hidden_size": 2048,
        "params": "25M",
        "description": "Deep residual convolutional backbone from Hugging Face Hub."
    },
    {
        "name": "runwayml/stable-diffusion-v1-5",
        "task": "image-generation",
        "modality": "image",
        "params": "860M",
        "description": "Latent text-to-image diffusion model capable of generating photo-realistic images."
    },
    {
        "name": "Salesforce/blip-image-captioning-base",
        "task": "image-to-text",
        "modality": "multimodal",
        "params": "223M",
        "description": "Unified vision-language pre-training model for image captioning and description."
    },
    {
        "name": "dandelin/vilt-b32-finetuned-vqa",
        "task": "visual-question-answering",
        "modality": "multimodal",
        "params": "87M",
        "description": "Fast and lightweight vision-and-language transformer fine-tuned on VQAv2."
    },
    {
        "name": "gpt2",
        "task": "text-generation",
        "modality": "text",
        "params": "124M",
        "description": "Causal autoregressive transformer for open-ended text completion and generation."
    },
]


def list_popular_hf_models(task: Optional[str] = None, modality: Optional[str] = None) -> List[Dict[str, Any]]:
    """Return a curated list of recommended Hugging Face models for TuiML."""
    models = POPULAR_HF_MODELS
    if task:
        models = [m for m in models if m["task"] == task or task in m["task"]]
    if modality:
        models = [m for m in models if m["modality"] == modality]
    return models


def create_hf_transformer_layer_class():
    """Dynamically create HFTransformerLayer subclass of keras.layers.Layer."""
    import keras
    import torch
    from transformers import AutoModel, AutoConfig

    class HFTransformerLayer(keras.layers.Layer):
        """Keras layer wrapping a Hugging Face Transformer or Vision backbone.

        Seamlessly executes a pretrained Hugging Face PyTorch model inside
        Keras 3 models using PyTorch backend. Supports configurable pooling
        (mean, cls, max, or none) and fine-tuning or feature extraction freezing.

        Parameters
        ----------
        model_name : str, default="sentence-transformers/all-MiniLM-L6-v2"
            Hugging Face Hub model identifier or path to local checkpoint.
        pooling : str, default="mean"
            Pooling strategy for sequence tokens: ``"mean"``, ``"cls"``, ``"max"``, or ``"none"``.
        trainable : bool, default=False
            Whether to update transformer weights during training (fine-tuning)
            or keep them frozen (feature extraction).
        modality : str, default="auto"
            Input modality: ``"auto"``, ``"text"``, or ``"vision"``.
        """

        def __init__(
            self,
            model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
            pooling: str = "mean",
            trainable: bool = False,
            modality: str = "auto",
            **kwargs,
        ):
            super().__init__(**kwargs)
            self.model_name = model_name
            self.pooling = pooling
            self.hf_trainable = trainable
            self.modality = modality
            self.hidden_size: Optional[int] = None
            self.hf_model = None
            self.hf_wrapper = None

        def build(self, input_shape):
            _ensure_transformers()
            config = AutoConfig.from_pretrained(self.model_name)
            self.hidden_size = getattr(
                config,
                "hidden_size",
                getattr(config, "d_model", getattr(config, "dim", 384)),
            )

            # Auto-detect vision vs text if set to auto
            if self.modality == "auto":
                arch_str = "".join(getattr(config, "architectures", []) or []).lower()
                if "vit" in arch_str or "vision" in arch_str or "resnet" in arch_str or "convnext" in arch_str:
                    self.modality = "vision"
                elif len(input_shape) >= 4:
                    self.modality = "vision"
                else:
                    self.modality = "text"

            self.trainable = self.hf_trainable
            self.hf_model = AutoModel.from_pretrained(self.model_name)
            for param in self.hf_model.parameters():
                param.requires_grad = self.hf_trainable

            self.hf_wrapper = keras.layers.TorchModuleWrapper(self.hf_model)
            self.hf_wrapper.trainable = self.hf_trainable
            super().build(input_shape)

        def call(self, inputs, attention_mask=None):
            if torch.is_tensor(inputs):
                inp = inputs
            else:
                inp = torch.as_tensor(inputs)

            if self.modality == "vision":
                # Keras image format is typically (B, H, W, C)
                # PyTorch vision models expect (B, C, H, W)
                if inp.ndim == 4 and inp.shape[-1] in (1, 3, 4) and inp.shape[1] > 4:
                    inp = inp.permute(0, 3, 1, 2)
                outputs = self.hf_wrapper(pixel_values=inp.float())
                hidden_states = getattr(outputs, "last_hidden_state", outputs[0])
                if self.pooling == "cls":
                    return hidden_states[:, 0]
                elif self.pooling == "mean":
                    # Mean over spatial/patch dimensions
                    return torch.mean(hidden_states, dim=1)
                elif self.pooling == "max":
                    return torch.max(hidden_states, dim=1)[0]
                return hidden_states

            # Text modality: inputs are token IDs (batch_size, seq_len)
            input_ids = inp.long()
            if attention_mask is None:
                attention_mask = (input_ids != 0).long()
            elif not torch.is_tensor(attention_mask):
                attention_mask = torch.as_tensor(attention_mask, dtype=torch.long)
            else:
                attention_mask = attention_mask.long()

            outputs = self.hf_wrapper(input_ids=input_ids, attention_mask=attention_mask)
            hidden_states = getattr(outputs, "last_hidden_state", outputs[0])

            if self.pooling == "mean":
                mask_expanded = attention_mask.unsqueeze(-1).expand_as(hidden_states).float()
                sum_embeddings = torch.sum(hidden_states * mask_expanded, dim=1)
                sum_mask = mask_expanded.sum(dim=1).clamp(min=1e-9)
                return sum_embeddings / sum_mask
            elif self.pooling == "cls":
                return hidden_states[:, 0]
            elif self.pooling == "max":
                return torch.max(hidden_states, dim=1)[0]
            elif self.pooling in ("none", None):
                return hidden_states
            return hidden_states

        def compute_output_shape(self, input_shape):
            h_size = self.hidden_size or 384
            if self.pooling in ("mean", "cls", "max"):
                return (input_shape[0], h_size)
            if len(input_shape) > 1:
                return (input_shape[0], input_shape[1], h_size)
            return (input_shape[0], h_size)

        def get_config(self) -> Dict[str, Any]:
            config = super().get_config()
            config.update({
                "model_name": self.model_name,
                "pooling": self.pooling,
                "trainable": self.hf_trainable,
                "modality": self.modality,
            })
            return config

    return HFTransformerLayer


_HF_LAYER_CLASS = None


def get_hf_transformer_layer():
    """Return the HFTransformerLayer class, initializing lazily."""
    global _HF_LAYER_CLASS
    if _HF_LAYER_CLASS is None:
        _ensure_transformers()
        _HF_LAYER_CLASS = create_hf_transformer_layer_class()
    return _HF_LAYER_CLASS


def build_hf_layer(class_name: str, config: Dict[str, Any]):
    """Instantiate a Hugging Face layer from class name and configuration."""
    cls = get_hf_transformer_layer()
    clean_config = dict(config)
    # Map common aliases
    if "pretrained_model_name_or_path" in clean_config and "model_name" not in clean_config:
        clean_config["model_name"] = clean_config.pop("pretrained_model_name_or_path")
    return cls(**clean_config)
