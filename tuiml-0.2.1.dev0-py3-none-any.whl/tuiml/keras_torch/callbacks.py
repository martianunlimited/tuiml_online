"""Training callbacks for progress monitoring, speed measurement, and ETA estimation."""

import json
import logging
import os
import time
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger(__name__)


def _format_time(seconds: float) -> str:
    """Format duration in seconds to human-readable string."""
    if seconds < 0:
        return "0s"
    seconds = int(round(seconds))
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    rem_sec = seconds % 60
    if minutes < 60:
        return f"{minutes}m {rem_sec:02d}s"
    hours = minutes // 60
    rem_min = minutes % 60
    return f"{hours}h {rem_min:02d}m"


try:
    import keras
    _BaseCallback = keras.callbacks.Callback
except Exception:
    _BaseCallback = object


class TuiMLProgressCallback(_BaseCallback):
    """Keras-compatible callback reporting progress, samples/sec, and ETA.

    Works cleanly across both synchronous and asynchronous training, writing
    real-time progress to a status dictionary and optional JSON status file.
    """

    def __init__(
        self,
        total_epochs: int = 10,
        total_samples: Optional[int] = None,
        batch_size: int = 32,
        log_interval_epochs: int = 1,
        status_file: Optional[str] = None,
        on_progress: Optional[Callable[[Dict[str, Any]], None]] = None,
        verbose: int = 1,
    ):
        super().__init__()
        self.total_epochs = total_epochs
        self.total_samples = total_samples
        self.batch_size = batch_size
        self.log_interval_epochs = max(1, log_interval_epochs)
        self.status_file = status_file
        self.on_progress = on_progress
        self.verbose = verbose

        self.start_time: float = 0.0
        self.epoch_start_time: float = 0.0
        self.epoch_durations = []
        self.progress_data: Dict[str, Any] = {
            "status": "pending",
            "epoch": 0,
            "total_epochs": self.total_epochs,
            "progress_pct": 0.0,
            "elapsed_seconds": 0.0,
            "eta_seconds": 0.0,
            "samples_per_second": 0.0,
            "metrics": {},
        }

    def __getstate__(self) -> Dict[str, Any]:
        """Custom pickling to exclude local closure callback hooks."""
        state = self.__dict__.copy()
        state["on_progress"] = None
        return state

    def __setstate__(self, state: Dict[str, Any]) -> None:
        self.__dict__.update(state)

    # Keras callback interface methods
    def on_train_begin(self, logs: Optional[Dict[str, Any]] = None) -> None:
        self.start_time = time.time()
        self.progress_data["status"] = "training"
        self._sync_status()

    def on_epoch_begin(self, epoch: int, logs: Optional[Dict[str, Any]] = None) -> None:
        self.epoch_start_time = time.time()

    def on_epoch_end(self, epoch: int, logs: Optional[Dict[str, Any]] = None) -> None:
        now = time.time()
        epoch_dur = max(now - self.epoch_start_time, 0.001)
        self.epoch_durations.append(epoch_dur)

        total_elapsed = now - self.start_time
        current_epoch = epoch + 1
        pct = round((current_epoch / self.total_epochs) * 100.0, 1)

        # Average speed across recent epochs
        recent_durations = self.epoch_durations[-5:]
        avg_epoch_dur = sum(recent_durations) / len(recent_durations)
        remaining_epochs = max(self.total_epochs - current_epoch, 0)
        eta_seconds = remaining_epochs * avg_epoch_dur

        # Speed calculation
        samples_per_sec = 0.0
        if self.total_samples is not None and self.total_samples > 0:
            samples_per_sec = self.total_samples / epoch_dur

        # Metrics cleaning
        clean_metrics = {}
        if logs:
            for k, v in logs.items():
                if isinstance(v, (int, float)):
                    clean_metrics[k] = round(float(v), 4)

        self.progress_data = {
            "status": "training",
            "epoch": current_epoch,
            "total_epochs": self.total_epochs,
            "progress_pct": pct,
            "elapsed_seconds": round(total_elapsed, 1),
            "epoch_duration_seconds": round(epoch_dur, 2),
            "eta_seconds": round(eta_seconds, 1),
            "eta_formatted": _format_time(eta_seconds),
            "samples_per_second": round(samples_per_sec, 1),
            "metrics": clean_metrics,
        }

        self._sync_status()

        # Console logging
        if self.verbose >= 1 and (current_epoch % self.log_interval_epochs == 0 or current_epoch == self.total_epochs):
            metrics_str = " | ".join(f"{k}: {v}" for k, v in clean_metrics.items())
            speed_str = f"{samples_per_sec:.0f} samples/s" if samples_per_sec > 0 else f"{epoch_dur:.2f}s/epoch"
            print(
                f"[TuiML Training] Epoch {current_epoch}/{self.total_epochs} ({pct}%) | "
                f"Time: {epoch_dur:.1f}s ({speed_str}) | ETA: {_format_time(eta_seconds)} | {metrics_str}"
            )

    def on_train_end(self, logs: Optional[Dict[str, Any]] = None) -> None:
        total_elapsed = time.time() - self.start_time
        self.progress_data["status"] = "completed"
        self.progress_data["elapsed_seconds"] = round(total_elapsed, 1)
        self.progress_data["eta_seconds"] = 0.0
        self.progress_data["eta_formatted"] = "0s"
        self.progress_data["progress_pct"] = 100.0
        self._sync_status()

        if self.verbose >= 1:
            print(
                f"[TuiML Training] Finished {self.total_epochs} epochs in "
                f"{_format_time(total_elapsed)} ({total_elapsed:.1f}s total)."
            )

    def _sync_status(self) -> None:
        """Propagate status to callback and disk status file if configured."""
        if self.on_progress:
            try:
                self.on_progress(dict(self.progress_data))
            except Exception as exc:
                logger.debug(f"Progress callback error: {exc}")

        if self.status_file:
            try:
                os.makedirs(os.path.dirname(os.path.abspath(self.status_file)), exist_ok=True)
                temp_file = f"{self.status_file}.tmp"
                with open(temp_file, "w") as f:
                    json.dump(self.progress_data, f, indent=2)
                os.replace(temp_file, self.status_file)
            except Exception as exc:
                logger.debug(f"Failed to write status file {self.status_file}: {exc}")
